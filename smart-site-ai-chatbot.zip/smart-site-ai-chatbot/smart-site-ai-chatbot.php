<?php
/**
 * Plugin Name:       Smart Site AI Chatbot
 * Plugin URI:        https://wordpress.org/plugins/smart-site-ai-chatbot/
 * Description:       Free AI chatbot and live assistant for WordPress and WooCommerce. Works out of the box with a built-in site-memory engine, or connect your own Gemini, OpenAI, OpenRouter or Groq API key. Includes lead capture, conversational booking, WooCommerce order lookup, page-aware prompts and shortcode or block embedding.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Md Tanvir Hossain
 * Author URI:        https://profiles.wordpress.org/tanvirapb/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       smart-site-ai-chatbot
 * Domain Path:       /languages
 *
 * @package Smart_Site_AI_Chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SSAC_VERSION', '1.0.0' );
define( 'SSAC_PLUGIN_FILE', __FILE__ );
define( 'SSAC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SSAC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Default plugin settings.
 *
 * Every business detail is intentionally left empty so the plugin ships with no
 * third-party contact information. Site owners fill these in under AI Chatbot.
 *
 * @return array
 */
function ssac_get_default_settings() {
	$site_name   = get_bloginfo( 'name' );
	$admin_email = get_option( 'admin_email' );

	return array(
		'enabled'                 => '1',
		'bot_name'                => $site_name ? $site_name . ' ' . __( 'Assistant', 'smart-site-ai-chatbot' ) : __( 'Site Assistant', 'smart-site-ai-chatbot' ),
		'bot_subtitle'            => __( 'Online - Instant site assistant', 'smart-site-ai-chatbot' ),
		'bot_avatar'              => '',
		'launcher_icon'           => 'chat',
		'launcher_custom_img'     => '',
		'position'                => 'right',
		'theme_mode'              => 'light',
		'primary_color'           => '#4F46E5',
		'accent_color'            => '#4338CA',
		'header_bg'               => '#0F172A',
		'welcome_message'         => __( 'Hello. I am your site assistant. Ask me about our services, pricing or products, check an order status, or book a call right here in chat.', 'smart-site-ai-chatbot' ),
		'tooltip_text'            => __( 'Need help? Ask our assistant', 'smart-site-ai-chatbot' ),
		'show_tooltip'            => '1',
		'enable_voice'            => '1',
		'enable_sound'            => '1',
		// Session persistence and rate limiting.
		'session_ttl_hours'       => '24',
		'rate_limit_per_min'      => '15',
		// Feature toggles.
		'enable_page_aware'       => '1',
		'enable_woo_order_lookup' => '1',
		'enable_whatsapp_handoff' => '0',
		'whatsapp_number'         => '',
		'enable_gdpr_consent'     => '0',
		'gdpr_consent_text'       => __( 'By starting a conversation you agree to our privacy policy and consent to storing your chat session for support purposes.', 'smart-site-ai-chatbot' ),
		'show_credit_link'        => '0',
		// AI provider settings. No key ships with the plugin.
		'ai_provider'             => 'local',
		'gemini_api_key'          => '',
		'gemini_model'            => 'gemini-2.5-flash',
		'openai_api_key'          => '',
		'openai_model'            => 'gpt-4o-mini',
		'openrouter_api_key'      => '',
		'openrouter_model'        => 'meta-llama/llama-3.3-70b-instruct:free',
		'groq_api_key'            => '',
		'groq_model'              => 'llama-3.3-70b-versatile',
		'temperature'             => '0.4',
		// Business profile. Empty by default.
		'business_name'           => $site_name ? $site_name : '',
		'business_website'        => home_url( '/' ),
		'business_email'          => $admin_email ? $admin_email : '',
		'business_phone'          => '',
		'business_hours'          => '',
		'booking_url'             => '',
		// Empty means the starter prompts are generated from the site content.
		'demo_prompts'            => '',
		'custom_knowledge'        => '',
		'system_instructions'     => __( 'You are a helpful, accurate and polite website assistant. Answer using the provided website memory and context. Keep answers clear, well structured and concise, with direct links. Never reveal administrator passwords, API keys, configuration files or internal security credentials.', 'smart-site-ai-chatbot' ),
	);
}

/**
 * Get merged plugin settings.
 *
 * @return array
 */
function ssac_get_settings() {
	$defaults = ssac_get_default_settings();
	$saved    = get_option( 'ssac_chatbot_settings', array() );

	if ( ! is_array( $saved ) ) {
		$saved = array();
	}

	return wp_parse_args( $saved, $defaults );
}

require_once SSAC_PLUGIN_DIR . 'includes/class-ssac-indexer.php';
require_once SSAC_PLUGIN_DIR . 'includes/class-ssac-engine.php';
require_once SSAC_PLUGIN_DIR . 'includes/class-ssac-admin.php';
require_once SSAC_PLUGIN_DIR . 'includes/class-ssac-frontend.php';

/**
 * Initialise the plugin subsystems.
 *
 * @return void
 */
function ssac_init_plugin() {
	SSAC_Knowledge_Indexer::init();
	SSAC_Chat_Engine::init();
	SSAC_Admin_Settings::init();
	SSAC_Frontend_Widget::init();
}
add_action( 'plugins_loaded', 'ssac_init_plugin' );

/**
 * Activation: store defaults and schedule the first site memory build.
 *
 * The index is built on a scheduled event rather than during activation so a
 * large site cannot time out while the plugin is being switched on.
 *
 * @return void
 */
function ssac_activate_plugin() {
	$existing = get_option( 'ssac_chatbot_settings', false );

	if ( false === $existing || ! is_array( $existing ) ) {
		update_option( 'ssac_chatbot_settings', ssac_get_default_settings() );
	} else {
		$updated            = ssac_get_settings();
		$updated['enabled'] = '1';
		update_option( 'ssac_chatbot_settings', $updated );
	}

	SSAC_Knowledge_Indexer::register_chatbot_leads_cpt();
	SSAC_Knowledge_Indexer::schedule_sync( true );
}
register_activation_hook( __FILE__, 'ssac_activate_plugin' );

/**
 * Deactivation: clear scheduled events and per-visitor runtime state.
 *
 * Settings, the site memory index and captured leads are preserved so the
 * plugin can be switched back on without losing data. Everything is removed by
 * uninstall.php when the plugin is deleted.
 *
 * @return void
 */
function ssac_deactivate_plugin() {
	wp_clear_scheduled_hook( SSAC_Knowledge_Indexer::SYNC_EVENT );
	SSAC_Chat_Engine::purge_visitor_state();
}
register_deactivation_hook( __FILE__, 'ssac_deactivate_plugin' );

/**
 * Add a settings link on the plugins list table.
 *
 * @param array $links Existing action links.
 * @return array
 */
function ssac_plugin_action_links( $links ) {
	$settings_link = sprintf(
		'<a href="%s">%s</a>',
		esc_url( admin_url( 'admin.php?page=smart-site-ai-chatbot' ) ),
		esc_html__( 'Settings', 'smart-site-ai-chatbot' )
	);

	array_unshift( $links, $settings_link );

	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'ssac_plugin_action_links' );
