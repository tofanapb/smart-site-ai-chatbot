<?php
/**
 * Site knowledge indexer.
 *
 * Builds a searchable in-database index of the public content on the site so the
 * assistant can answer questions without an external AI service.
 *
 * @package Smart_Site_AI_Chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Crawls public content into a site memory index.
 */
class SSAC_Knowledge_Indexer {

	const INDEX_OPTION_KEY = 'ssac_site_knowledge_index';
	const STATS_OPTION_KEY = 'ssac_site_knowledge_stats';
	const SYNC_EVENT       = 'ssac_sync_site_memory_event';

	/**
	 * Index format version. Bumping it rebuilds indexes built by older
	 * versions, so a plugin update never reads a stale shape.
	 */
	const SCHEMA_VERSION = 2;
	const SYNC_LOCK_KEY    = 'ssac_sync_queued';

	/**
	 * Guard against double initialisation.
	 *
	 * @var bool
	 */
	private static $initialized = false;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		if ( self::$initialized ) {
			return;
		}
		self::$initialized = true;

		add_action( 'init', array( __CLASS__, 'register_chatbot_leads_cpt' ), 7 );
		add_action( 'save_post', array( __CLASS__, 'on_post_saved_or_updated' ), 25, 2 );
		add_action( 'deleted_post', array( __CLASS__, 'on_post_deleted' ), 20 );
		add_action( self::SYNC_EVENT, array( __CLASS__, 'run_scheduled_sync' ) );
	}

	/**
	 * Register the private post type used to store leads and bookings.
	 *
	 * @return void
	 */
	public static function register_chatbot_leads_cpt() {
		register_post_type(
			'ssac_lead',
			array(
				'labels'          => array(
					'name'          => __( 'Chatbot leads and bookings', 'smart-site-ai-chatbot' ),
					'singular_name' => __( 'Chatbot lead', 'smart-site-ai-chatbot' ),
				),
				'public'          => false,
				'show_ui'         => false,
				'show_in_rest'    => false,
				'supports'        => array( 'title', 'editor', 'custom-fields' ),
				'capability_type' => 'post',
				'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
				'map_meta_cap'    => true,
			)
		);
	}

	/**
	 * Queue a site memory rebuild.
	 *
	 * Content changes only ever schedule the crawl. Rebuilding inline would run a
	 * full site crawl on every single post save, which is unusable during bulk
	 * imports or WooCommerce stock updates.
	 *
	 * @param bool $immediate Run the crawl now instead of scheduling it.
	 * @return void
	 */
	public static function schedule_sync( $immediate = false ) {
		if ( $immediate ) {
			delete_transient( self::SYNC_LOCK_KEY );
			self::sync_all_site_memory();
			return;
		}

		// Already queued: nothing to do until the pending event has run.
		if ( get_transient( self::SYNC_LOCK_KEY ) ) {
			return;
		}

		set_transient( self::SYNC_LOCK_KEY, 1, 10 * MINUTE_IN_SECONDS );

		if ( ! wp_next_scheduled( self::SYNC_EVENT ) ) {
			wp_schedule_single_event( time() + ( 2 * MINUTE_IN_SECONDS ), self::SYNC_EVENT );
		}
	}

	/**
	 * Scheduled callback that performs the queued crawl.
	 *
	 * @return void
	 */
	public static function run_scheduled_sync() {
		delete_transient( self::SYNC_LOCK_KEY );
		self::sync_all_site_memory();
	}

	/**
	 * Queue a rebuild when content is saved.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public static function on_post_saved_or_updated( $post_id, $post = null ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! is_object( $post ) ) {
			return;
		}

		if ( in_array( $post->post_type, self::get_ignored_post_types(), true ) ) {
			return;
		}

		self::schedule_sync();
	}

	/**
	 * Queue a rebuild when content is deleted.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function on_post_deleted( $post_id ) {
		if ( in_array( get_post_type( $post_id ), self::get_ignored_post_types(), true ) ) {
			return;
		}

		self::schedule_sync();
	}

	/**
	 * Post types that never affect the index.
	 *
	 * @return array
	 */
	public static function get_ignored_post_types() {
		return array(
			'ssac_lead',
			'revision',
			'nav_menu_item',
			'custom_css',
			'customize_changeset',
			'oembed_cache',
			'user_request',
			'wp_block',
			'wp_template',
			'wp_template_part',
			'wp_global_styles',
			'wp_navigation',
			'acf-field',
			'acf-field-group',
			'shop_order',
			'shop_order_refund',
			'shop_coupon',
			'scheduled-action',
		);
	}

	/**
	 * Whether a meta key is internal or sensitive and must never be indexed.
	 *
	 * @param string $key Meta key.
	 * @return bool
	 */
	public static function is_sensitive_meta_key( $key ) {
		$key_l = strtolower( (string) $key );

		if ( '' === $key_l || '_' === $key_l[0] ) {
			return true;
		}

		$blocked_patterns = array(
			'password',
			'pass',
			'secret',
			'token',
			'api_key',
			'apikey',
			'auth',
			'nonce',
			'hash',
			'salt',
			'private',
			'ssn',
			'credit_card',
			'card_number',
			'cvv',
			'stripe_',
			'paypal_',
			'session',
			'cookie',
			'user_login',
			'user_pass',
			'activation_key',
			'email',
			'phone',
			'billing_',
			'shipping_',
		);

		foreach ( $blocked_patterns as $pat ) {
			if ( false !== strpos( $key_l, $pat ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Convert markup into readable plain text.
	 *
	 * @param string $html Raw markup.
	 * @return string
	 */
	public static function clean_html_to_text( $html ) {
		if ( empty( $html ) || ! is_string( $html ) ) {
			return '';
		}

		$html = preg_replace( '/<(script|style|svg|noscript)\b[^>]*>.*?<\/\1>/is', ' ', $html );
		$html = preg_replace( '/<\/(p|div|h1|h2|h3|h4|h5|h6|li|tr|section|article|dd|dt)>/i', "\n", $html );
		$html = preg_replace( '/<(br|hr)\s*\/?>/i', "\n", $html );

		$text = wp_strip_all_tags( html_entity_decode( $html, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		$text = preg_replace( '/[ \t]+/', ' ', $text );
		$text = preg_replace( '/\n\s*\n+/', "\n", $text );

		return trim( $text );
	}

	/**
	 * Extract content images from markup.
	 *
	 * @param string $html Raw markup.
	 * @return array
	 */
	public static function extract_images_from_html( $html ) {
		$images = array();

		if ( empty( $html ) || ! is_string( $html ) ) {
			return $images;
		}

		if ( preg_match_all( '/<img\b[^>]*src=["\']([^"\']+)["\'][^>]*>/is', $html, $matches, PREG_SET_ORDER ) ) {
			foreach ( $matches as $m ) {
				$src = trim( $m[1] );

				if ( '' === $src || 0 === strpos( $src, 'data:' ) ) {
					continue;
				}

				$alt = '';
				if ( preg_match( '/alt=["\']([^"\']*)["\']/i', $m[0], $am ) ) {
					$alt = trim( $am[1] );
				}

				$images[] = array(
					'url'     => esc_url_raw( $src ),
					'alt'     => sanitize_text_field( $alt ),
					'is_icon' => (bool) preg_match( '/width=["\']?([0-9]{1,2})["\']?/i', $m[0] ),
				);
			}
		}

		return $images;
	}

	/**
	 * Extract question and answer pairs from a post.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $raw_html Raw post markup.
	 * @return array
	 */
	public static function extract_faqs_from_post( $post_id, $raw_html = '' ) {
		$faqs = array();

		if ( ! empty( $raw_html ) ) {
			if ( preg_match_all( '/<details\b[^>]*>\s*<summary\b[^>]*>(.*?)<\/summary>\s*(.*?)<\/details>/is', $raw_html, $dm, PREG_SET_ORDER ) ) {
				foreach ( $dm as $m ) {
					$faqs[] = array(
						'q' => self::clean_html_to_text( $m[1] ),
						'a' => self::clean_html_to_text( $m[2] ),
					);
				}
			}
		}

		/**
		 * Filter the question and answer pairs indexed for a post.
		 *
		 * Lets a theme or site-specific plugin feed its own FAQ fields into the
		 * assistant's memory.
		 *
		 * @param array  $faqs     Pairs with `q` and `a` keys.
		 * @param int    $post_id  Post ID.
		 * @param string $raw_html Raw post markup.
		 */
		$faqs = apply_filters( 'ssac_post_faqs', $faqs, $post_id, $raw_html );

		if ( ! is_array( $faqs ) ) {
			return array();
		}

		return array_slice( $faqs, 0, 12 );
	}

	/**
	 * Build the site memory index.
	 *
	 * @return array
	 */
	public static function sync_all_site_memory() {
		$settings = ssac_get_settings();

		$post_types = get_post_types(
			array(
				'public'              => true,
				'exclude_from_search' => false,
			),
			'names'
		);
		unset( $post_types['attachment'] );

		$ignored = self::get_ignored_post_types();
		foreach ( $ignored as $skip ) {
			unset( $post_types[ $skip ] );
		}

		/**
		 * Filter the post types indexed into the site memory.
		 *
		 * @param array $post_types Post type names.
		 */
		$post_types = apply_filters( 'ssac_indexed_post_types', array_values( $post_types ) );

		/**
		 * Filter how many items the site memory index holds.
		 *
		 * @param int $limit Maximum number of indexed entries.
		 */
		$limit = (int) apply_filters( 'ssac_index_item_limit', 250 );

		$posts = get_posts(
			array(
				'post_type'        => $post_types,
				'post_status'      => 'publish',
				'posts_per_page'   => $limit,
				'orderby'          => 'menu_order date',
				'order'            => 'ASC',
				'no_found_rows'    => true,
				'has_password'     => false,
				'suppress_filters' => false,
			)
		);

		$items         = array();
		$all_images    = array();
		$all_faqs      = array();
		$product_cats  = array();
		$page_slugs    = array();
		$counts     = array(
			'pages'        => 0,
			'posts'        => 0,
			'products'     => 0,
			'services'     => 0,
			'case_studies' => 0,
			'images'       => 0,
			'faqs'         => 0,
		);

		foreach ( $posts as $p ) {
			if ( 'publish' !== $p->post_status || ! empty( $p->post_password ) ) {
				continue;
			}

			$post_id   = (int) $p->ID;
			$post_type = $p->post_type;
			$slug      = $p->post_name;
			$title     = get_the_title( $post_id );
			$permalink = get_permalink( $post_id );
			$raw_html  = (string) $p->post_content;

			$excerpt_text = self::clean_html_to_text( $p->post_excerpt );

			$meta_snippets = array();
			$all_meta      = get_post_meta( $post_id );

			if ( is_array( $all_meta ) ) {
				foreach ( $all_meta as $m_key => $m_vals ) {
					if ( self::is_sensitive_meta_key( $m_key ) ) {
						continue;
					}

					$val = isset( $m_vals[0] ) ? maybe_unserialize( $m_vals[0] ) : '';

					if ( is_string( $val ) && '' !== trim( $val ) && strlen( $val ) < 1500 && 0 !== strpos( $val, 'field_' ) ) {
						$cleaned_meta = self::clean_html_to_text( $val );

						if ( strlen( $cleaned_meta ) > 3 ) {
							$meta_snippets[] = $cleaned_meta;
						}
					}
				}
			}

			$thumb_url   = get_the_post_thumbnail_url( $post_id, 'medium' );
			$html_images = self::extract_images_from_html( $raw_html );

			foreach ( $html_images as $hi ) {
				if ( $hi['is_icon'] ) {
					continue;
				}

				if ( empty( $thumb_url ) ) {
					$thumb_url = $hi['url'];
				}

				if ( count( $all_images ) < 80 ) {
					$all_images[] = array(
						'url'        => $hi['url'],
						'alt'        => ! empty( $hi['alt'] ) ? $hi['alt'] : $title,
						'page_title' => $title,
						'page_url'   => $permalink,
					);
				}
			}

			$post_faqs = self::extract_faqs_from_post( $post_id, $raw_html );

			foreach ( $post_faqs as $pf ) {
				$all_faqs[] = array(
					'q'          => $pf['q'],
					'a'          => $pf['a'],
					'page_title' => $title,
					'page_url'   => $permalink,
				);
			}

			$entity_type         = 'page';
			$category            = '';
			$price_label         = '';
			$buy_url             = $permalink;
			$cta_label           = __( 'Open', 'smart-site-ai-chatbot' );
			$secondary_cta_label = '';
			$secondary_cta_url   = '';
			$badges              = array();

			if ( 'product' === $post_type || 'download' === $post_type ) {
				$entity_type = 'product';
				++$counts['products'];

				if ( function_exists( 'wc_get_product' ) ) {
					$wc_prod = wc_get_product( $post_id );

					if ( $wc_prod ) {
						$price_label         = wp_strip_all_tags( $wc_prod->get_price_html() );
						$buy_url             = $permalink;
						$cta_label           = __( 'View product', 'smart-site-ai-chatbot' );
						$secondary_cta_label = '';
						$terms               = get_the_terms( $post_id, 'product_cat' );

						if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
							$category = $terms[0]->name;

							foreach ( $terms as $t ) {
								$badges[] = $t->name;

								if ( ! isset( $product_cats[ $t->name ] ) ) {
									$product_cats[ $t->name ] = 0;
								}

								++$product_cats[ $t->name ];
							}
						}
					}
				} else {
					$price_label = __( 'Product', 'smart-site-ai-chatbot' );
					$cta_label    = __( 'View product', 'smart-site-ai-chatbot' );
				}
			} elseif ( 'case_study' === $post_type || 'portfolio' === $post_type ) {
				$entity_type = 'case_study';
				++$counts['case_studies'];
				$cta_label           = __( 'View case study', 'smart-site-ai-chatbot' );
				$secondary_cta_label = __( 'Book', 'smart-site-ai-chatbot' );
				$secondary_cta_url   = '#ssac-book:' . rawurlencode( $title );
			} elseif ( 'service' === $post_type ) {
				$entity_type = 'service';
				++$counts['services'];
				$category            = __( 'Service', 'smart-site-ai-chatbot' );
				$price_label         = $category;
				$cta_label           = __( 'View details', 'smart-site-ai-chatbot' );
				$secondary_cta_label = __( 'Book', 'smart-site-ai-chatbot' );
				$secondary_cta_url   = '#ssac-book:' . rawurlencode( $title );
				$badges[]            = $category;
			} elseif ( 'post' === $post_type ) {
				$entity_type = 'post';
				++$counts['posts'];
				$cats = get_the_category( $post_id );

				if ( ! empty( $cats ) ) {
					$category = $cats[0]->name;
					$badges[] = $category;
				}

				$price_label = $category ? $category : __( 'Article', 'smart-site-ai-chatbot' );
				$cta_label   = __( 'Read article', 'smart-site-ai-chatbot' );
			} else {
				++$counts['pages'];
				$category     = __( 'Page', 'smart-site-ai-chatbot' );
				$price_label  = $category;
				$page_slugs[] = strtolower( $slug . ' ' . $title );
			}

			$body_text = self::clean_html_to_text( $raw_html );

			if ( empty( $excerpt_text ) ) {
				$excerpt_text = wp_trim_words( $body_text, 14, '...' );
			}

			// Page builders and block themes often keep the copy out of
			// post_content, so fall back to the indexed meta text.
			if ( empty( $excerpt_text ) && ! empty( $meta_snippets ) ) {
				$excerpt_text = wp_trim_words( implode( ' ', $meta_snippets ), 14, '...' );
			}

			$combined_search_text = $title . "\n" . $category . "\n" . $excerpt_text . "\n"
				. implode( "\n", array_unique( $meta_snippets ) ) . "\n"
				. mb_substr( $body_text, 0, 3000 );

			$items[] = array(
				'id'                  => $post_id,
				'type'                => $entity_type,
				'post_type'           => $post_type,
				'slug'                => $slug,
				'title'               => $title,
				'url'                 => $permalink,
				'buy_url'             => $buy_url,
				'category'            => $category,
				'price_label'         => $price_label,
				'summary'             => wp_trim_words( $excerpt_text, 11, '...' ),
				'full_summary'        => wp_trim_words( $excerpt_text, 26, '...' ),
				'content'             => mb_substr( $combined_search_text, 0, 3500 ),
				'image'               => $thumb_url ? $thumb_url : '',
				'badges'              => array_slice( array_values( array_unique( array_filter( $badges ) ) ), 0, 2 ),
				'cta_label'           => $cta_label,
				'secondary_cta_label' => $secondary_cta_label,
				'secondary_cta_url'   => $secondary_cta_url,
			);
		}

		$counts['images'] = count( $all_images );
		$counts['faqs']   = count( $all_faqs );

		$site_info = array(
			'name'             => get_bloginfo( 'name' ),
			'tagline'          => get_bloginfo( 'description' ),
			'url'              => home_url( '/' ),
			'business_name'    => ! empty( $settings['business_name'] ) ? $settings['business_name'] : get_bloginfo( 'name' ),
			'business_website' => ! empty( $settings['business_website'] ) ? $settings['business_website'] : home_url( '/' ),
			'email'            => ! empty( $settings['business_email'] ) ? $settings['business_email'] : '',
			'phone'            => ! empty( $settings['business_phone'] ) ? $settings['business_phone'] : '',
			'hours'            => ! empty( $settings['business_hours'] ) ? $settings['business_hours'] : '',
			'booking_url'      => ! empty( $settings['booking_url'] ) ? $settings['booking_url'] : '',
			'custom_knowledge' => ! empty( $settings['custom_knowledge'] ) ? $settings['custom_knowledge'] : '',
		);

		$index_payload = array(
			'schema'        => self::SCHEMA_VERSION,
			'synced_at'     => current_time( 'mysql' ),
			'site_info'     => $site_info,
			'counts'        => $counts,
			'quick_actions' => self::build_quick_actions( $counts, $product_cats, $page_slugs, $settings ),
			'items'         => $items,
			'images'        => array_slice( $all_images, 0, 60 ),
			'faqs'          => array_slice( $all_faqs, 0, 60 ),
		);

		update_option( self::INDEX_OPTION_KEY, $index_payload, false );
		update_option(
			self::STATS_OPTION_KEY,
			array(
				'synced_at'   => $index_payload['synced_at'],
				'counts'      => $counts,
				'total_items' => count( $items ),
			),
			false
		);

		return $index_payload;
	}

	/**
	 * Decide which quick actions suit this particular site.
	 *
	 * A shop gets its products and busiest product categories, an agency gets
	 * its services and portfolio, a publication gets its articles. Everything
	 * is derived from what the crawl actually found, so an empty site shows
	 * nothing it cannot answer.
	 *
	 * @param array $counts       Content counts from the crawl.
	 * @param array $product_cats Product category name => product count.
	 * @param array $page_slugs   Lowercase "slug title" strings for indexed pages.
	 * @param array $settings     Plugin settings.
	 * @return array List of arrays with `label`, `prompt` and `icon` keys.
	 */
	public static function build_quick_actions( $counts, $product_cats, $page_slugs, $settings ) {
		$haystack = ' ' . implode( ' | ', $page_slugs ) . ' ';

		$has_page = static function ( $needles ) use ( $haystack ) {
			foreach ( (array) $needles as $needle ) {
				if ( false !== strpos( $haystack, $needle ) ) {
					return true;
				}
			}

			return false;
		};

		$is_shop      = $counts['products'] > 0;
		$has_services = $counts['services'] > 0 || $has_page( array( 'service', 'what-we-do', 'solution' ) );
		$has_work     = $counts['case_studies'] > 0 || $has_page( array( 'portfolio', 'case-stud', 'our-work', 'project' ) );
		$has_pricing  = $has_page( array( 'pricing', 'plans', 'package' ) );
		$has_articles = $counts['posts'] >= 3;
		$woo_lookup   = ( ! isset( $settings['enable_woo_order_lookup'] ) || '1' === $settings['enable_woo_order_lookup'] )
			&& function_exists( 'wc_get_order' );

		$commerce = array();
		$content  = array();

		if ( $is_shop ) {
			$commerce[] = array(
				'label'  => __( 'Products', 'smart-site-ai-chatbot' ),
				'prompt' => __( 'Show me your products', 'smart-site-ai-chatbot' ),
				'icon'   => 'box',
			);

			// The busiest categories first: they are what most visitors ask about.
			arsort( $product_cats );

			foreach ( array_slice( array_keys( $product_cats ), 0, 2 ) as $cat_name ) {
				$commerce[] = array(
					'label'  => $cat_name,
					/* translators: %s: product category name. */
					'prompt' => sprintf( __( 'Show me %s', 'smart-site-ai-chatbot' ), $cat_name ),
					'icon'   => 'tag',
				);
			}
		}

		if ( $woo_lookup ) {
			$commerce[] = array(
				'label'  => __( 'Track order', 'smart-site-ai-chatbot' ),
				'prompt' => __( 'Track my order', 'smart-site-ai-chatbot' ),
				'icon'   => 'package',
			);
		}

		if ( $has_services ) {
			$content[] = array(
				'label'  => __( 'Services', 'smart-site-ai-chatbot' ),
				'prompt' => __( 'What services do you offer?', 'smart-site-ai-chatbot' ),
				'icon'   => 'briefcase',
			);
		}

		if ( $has_work ) {
			$content[] = array(
				'label'  => __( 'Our work', 'smart-site-ai-chatbot' ),
				'prompt' => __( 'Show me your case studies', 'smart-site-ai-chatbot' ),
				'icon'   => 'chart',
			);
		}

		if ( $has_pricing ) {
			$content[] = array(
				'label'  => __( 'Pricing', 'smart-site-ai-chatbot' ),
				'prompt' => __( 'What are your prices?', 'smart-site-ai-chatbot' ),
				'icon'   => 'tag',
			);
		}

		if ( $has_articles ) {
			$content[] = array(
				'label'  => __( 'Articles', 'smart-site-ai-chatbot' ),
				'prompt' => __( 'Show me your latest articles', 'smart-site-ai-chatbot' ),
				'icon'   => 'file',
			);
		}

		// A shop leads with what it sells; everyone else leads with what they do.
		$actions = $is_shop ? array_merge( $commerce, $content ) : array_merge( $content, $commerce );

		$actions[] = array(
			'label'  => __( 'Book a call', 'smart-site-ai-chatbot' ),
			'prompt' => __( 'Book a call', 'smart-site-ai-chatbot' ),
			'icon'   => 'calendar',
		);

		$actions[] = array(
			'label'  => __( 'Contact us', 'smart-site-ai-chatbot' ),
			'prompt' => __( 'Project inquiry', 'smart-site-ai-chatbot' ),
			'icon'   => 'mail',
		);

		$actions = array_slice( $actions, 0, 6 );

		/**
		 * Filter the quick actions shown in the chat window.
		 *
		 * @param array $actions Each with `label`, `prompt` and `icon` keys.
		 * @param array $counts  Content counts from the crawl.
		 */
		return apply_filters( 'ssac_quick_actions', $actions, $counts );
	}

	/**
	 * Get the current site memory index, building it once if it is missing.
	 *
	 * @return array
	 */
	public static function get_memory_index() {
		$index = get_option( self::INDEX_OPTION_KEY, false );

		$is_usable = ! empty( $index )
			&& is_array( $index )
			&& isset( $index['items'] )
			&& isset( $index['schema'] )
			&& (int) $index['schema'] === self::SCHEMA_VERSION;

		if ( ! $is_usable ) {
			$index = self::sync_all_site_memory();
		}

		return $index;
	}
}
