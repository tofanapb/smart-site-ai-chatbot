<?php
/**
 * Human-Crafted SaaS Admin Dashboard for Smart Site AI Chatbot (v1.0.0)
 * Zero Emojis — Crisp Vector Stroke SVG Icons, Persistent Session Controls,
 * Live Chat Sessions Viewer, 1-Click CSV Export & Right-Side Developer Showcase Card
 *
 * @package Smart_Site_AI_Chatbot
 * @author  Md Tanvir Hossain
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SSAC_Admin_Settings {

	private static $initialized = false;

	public static function init() {
		if ( self::$initialized ) {
			return;
		}
		self::$initialized = true;
		add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_admin_actions' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
	}

	public static function register_admin_menu() {
		add_menu_page(
			__( 'Smart Site AI Chatbot', 'smart-site-ai-chatbot' ),
			__( 'AI Chatbot', 'smart-site-ai-chatbot' ),
			'manage_options',
			'smart-site-ai-chatbot',
			array( __CLASS__, 'render_admin_page' ),
			'dashicons-format-chat',
			3
		);
	}

	public static function enqueue_admin_assets( $hook ) {
		if ( false === strpos( $hook, 'smart-site-ai-chatbot' ) ) {
			return;
		}
		wp_enqueue_media();
	}

	/**
	 * Crisp Lucide-Style Inline Stroke SVG Helper (Zero Emojis)
	 */
	public static function svg_icon( $name, $size = 16 ) {
		$s = (int) $size;
		$attrs = 'viewBox="0 0 24 24" width="' . $s . '" height="' . $s . '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;vertical-align:-3px;"';
		switch ( $name ) {
			case 'bot':
				return '<svg ' . $attrs . '><rect x="3" y="8" width="18" height="12" rx="3"/><path d="M12 4v4"/><circle cx="9" cy="14" r="1"/><circle cx="15" cy="14" r="1"/></svg>';
			case 'sync':
				return '<svg ' . $attrs . '><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 16h5v5"/></svg>';
			case 'check':
				return '<svg ' . $attrs . '><path d="M20 6 9 17l-5-5"/></svg>';
			case 'sliders':
				return '<svg ' . $attrs . '><line x1="4" x2="4" y1="21" y2="14"/><line x1="4" x2="4" y1="10" y2="3"/><line x1="12" x2="12" y1="21" y2="12"/><line x1="12" x2="12" y1="8" y2="3"/><line x1="20" x2="20" y1="21" y2="16"/><line x1="20" x2="20" y1="12" y2="3"/><line x1="2" x2="6" y1="14" y2="14"/><line x1="10" x2="14" y1="8" y2="8"/><line x1="18" x2="22" y1="16" y2="16"/></svg>';
			case 'cpu':
				return '<svg ' . $attrs . '><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3"/><path d="M15 1v3"/><path d="M9 20v3"/><path d="M15 20v3"/><path d="M20 9h3"/><path d="M20 14h3"/><path d="M1 9h3"/><path d="M1 14h3"/></svg>';
			case 'database':
				return '<svg ' . $attrs . '><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5V19A9 3 0 0 0 21 19V5"/><path d="M3 12A9 3 0 0 0 21 12"/></svg>';
			case 'calendar':
				return '<svg ' . $attrs . '><rect width="18" height="18" x="3" y="4" rx="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>';
			case 'history':
				return '<svg ' . $attrs . '><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/></svg>';
			case 'save':
				return '<svg ' . $attrs . '><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>';
			case 'download':
				return '<svg ' . $attrs . '><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>';
			case 'trash':
				return '<svg ' . $attrs . '><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>';
			case 'globe':
				return '<svg ' . $attrs . '><circle cx="12" cy="12" r="10"/><line x1="2" x2="22" y1="12" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>';
			case 'phone':
				return '<svg ' . $attrs . '><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>';
			case 'mail':
				return '<svg ' . $attrs . '><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>';
			case 'code':
				return '<svg ' . $attrs . '><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>';
			case 'mic':
				return '<svg ' . $attrs . '><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>';
			case 'bell':
				return '<svg ' . $attrs . '><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>';
			case 'shield':
				return '<svg ' . $attrs . '><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>';
			default:
				return '<svg ' . $attrs . '><circle cx="12" cy="12" r="10"/></svg>';
		}
	}

	/**
	 * Neutralise a value that a spreadsheet would otherwise treat as a formula.
	 *
	 * @param mixed $value Cell value.
	 * @return string
	 */
	public static function csv_safe( $value ) {
		$value = (string) $value;

		if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $value;
		}

		return $value;
	}

	/**
	 * Build one CSV line.
	 *
	 * The export is assembled in memory and echoed, rather than written through
	 * a stream handle, so the plugin makes no direct filesystem calls.
	 *
	 * @param array $fields Cell values.
	 * @return string
	 */
	public static function csv_row( $fields ) {
		$cells = array();

		foreach ( $fields as $field ) {
			$cells[] = '"' . str_replace( '"', '""', self::csv_safe( $field ) ) . '"';
		}

		return implode( ',', $cells ) . "\r\n";
	}

	public static function handle_admin_actions() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// 1. Save Settings
		if ( isset( $_POST['ssac_save_settings_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ssac_save_settings_nonce'] ) ), 'ssac_save_settings_action' ) ) {
			$current = ssac_get_settings();
			$fields  = array(
				'bot_name'            => 'text',
				'bot_subtitle'        => 'text',
				'bot_avatar'          => 'url',
				'launcher_icon'       => 'key',
				'launcher_custom_img' => 'url',
				'position'            => 'key',
				'theme_mode'          => 'key',
				'primary_color'       => 'text',
				'accent_color'        => 'text',
				'header_bg'           => 'text',
				'welcome_message'     => 'textarea',
				'tooltip_text'        => 'text',
				'demo_prompts'        => 'textarea',
				'session_ttl_hours'   => 'text',
				'rate_limit_per_min'  => 'text',
				'whatsapp_number'     => 'text',
				'gdpr_consent_text'   => 'textarea',
				'ai_provider'         => 'key',
				'gemini_api_key'      => 'text',
				'gemini_model'        => 'text',
				'openai_api_key'      => 'text',
				'openai_model'        => 'text',
				'openrouter_api_key'  => 'text',
				'openrouter_model'    => 'text',
				'groq_api_key'        => 'text',
				'groq_model'          => 'text',
				'temperature'         => 'text',
				'system_instructions' => 'textarea',
				'business_name'       => 'text',
				'business_website'    => 'url',
				'business_email'      => 'email',
				'business_phone'      => 'text',
				'business_hours'      => 'text',
				'booking_url'         => 'url',
				'custom_knowledge'    => 'textarea',
			);

			foreach ( $fields as $key => $type ) {
				if ( ! isset( $_POST[ $key ] ) ) {
					continue;
				}

				if ( 'textarea' === $type ) {
					$current[ $key ] = sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) );
				} elseif ( 'url' === $type ) {
					$current[ $key ] = esc_url_raw( wp_unslash( $_POST[ $key ] ) );
				} elseif ( 'email' === $type ) {
					$current[ $key ] = sanitize_email( wp_unslash( $_POST[ $key ] ) );
				} elseif ( 'key' === $type ) {
					$current[ $key ] = sanitize_key( wp_unslash( $_POST[ $key ] ) );
				} else {
					$current[ $key ] = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
				}
			}

			$current['enabled']                 = isset( $_POST['enabled'] ) ? '1' : '0';
			$current['show_tooltip']            = isset( $_POST['show_tooltip'] ) ? '1' : '0';
			$current['enable_voice']            = isset( $_POST['enable_voice'] ) ? '1' : '0';
			$current['enable_sound']            = isset( $_POST['enable_sound'] ) ? '1' : '0';
			$current['enable_page_aware']       = isset( $_POST['enable_page_aware'] ) ? '1' : '0';
			$current['enable_woo_order_lookup'] = isset( $_POST['enable_woo_order_lookup'] ) ? '1' : '0';
			$current['enable_whatsapp_handoff'] = isset( $_POST['enable_whatsapp_handoff'] ) ? '1' : '0';
			$current['enable_gdpr_consent']     = isset( $_POST['enable_gdpr_consent'] ) ? '1' : '0';
			$current['show_credit_link']        = isset( $_POST['show_credit_link'] ) ? '1' : '0';

			update_option( 'ssac_chatbot_settings', $current );

			wp_safe_redirect( add_query_arg( array( 'page' => 'smart-site-ai-chatbot', 'ssac_msg' => 'saved' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// 2. Manual 1-Click Site Memory Sync
		if ( isset( $_POST['ssac_sync_memory_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ssac_sync_memory_nonce'] ) ), 'ssac_sync_memory_action' ) ) {
			SSAC_Knowledge_Indexer::schedule_sync( true );
			wp_safe_redirect( add_query_arg( array( 'page' => 'smart-site-ai-chatbot', 'tab' => 'memory', 'ssac_msg' => 'synced' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// 3. Delete a Lead / Booking
		if ( isset( $_GET['ssac_delete_lead'], $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'ssac_delete_lead_action' ) ) {
			$del_id = (int) $_GET['ssac_delete_lead'];
			if ( $del_id && 'ssac_lead' === get_post_type( $del_id ) ) {
				wp_delete_post( $del_id, true );
			}
			wp_safe_redirect( add_query_arg( array( 'page' => 'smart-site-ai-chatbot', 'tab' => 'leads', 'ssac_msg' => 'deleted' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// 4. Feature 6: 1-Click CSV Export for Leads & Bookings
		if ( isset( $_GET['ssac_export_csv'], $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'ssac_export_csv_action' ) ) {
			$leads = get_posts(
				array(
					'post_type'      => 'ssac_lead',
					'posts_per_page' => 500,
					'post_status'    => 'publish',
					'orderby'        => 'date',
					'order'          => 'DESC',
				)
			);

			nocache_headers();
			header( 'Content-Type: text/csv; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="chatbot-leads-' . gmdate( 'Y-m-d' ) . '.csv"' );

			$csv = self::csv_row(
				array(
					__( 'Reference', 'smart-site-ai-chatbot' ),
					__( 'Type', 'smart-site-ai-chatbot' ),
					__( 'Name', 'smart-site-ai-chatbot' ),
					__( 'Email', 'smart-site-ai-chatbot' ),
					__( 'Phone', 'smart-site-ai-chatbot' ),
					__( 'Service', 'smart-site-ai-chatbot' ),
					__( 'Preferred date and time', 'smart-site-ai-chatbot' ),
					__( 'Details', 'smart-site-ai-chatbot' ),
					__( 'Submitted', 'smart-site-ai-chatbot' ),
				)
			);

			foreach ( $leads as $ld ) {
				$csv .= self::csv_row(
					array(
						get_post_meta( $ld->ID, 'ssac_lead_ref', true ),
						get_post_meta( $ld->ID, 'ssac_lead_type', true ),
						get_post_meta( $ld->ID, 'ssac_lead_name', true ),
						get_post_meta( $ld->ID, 'ssac_lead_email', true ),
						get_post_meta( $ld->ID, 'ssac_lead_phone', true ),
						get_post_meta( $ld->ID, 'ssac_lead_service', true ),
						get_post_meta( $ld->ID, 'ssac_lead_datetime', true ),
						wp_strip_all_tags( $ld->post_content ),
						$ld->post_date,
					)
				);
			}

			echo $csv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSV body, not HTML; cells are quoted and escaped by csv_row().
			exit;
		}

		// 5. Clear Visitor Chat Sessions Log
		if ( isset( $_POST['ssac_clear_sessions_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ssac_clear_sessions_nonce'] ) ), 'ssac_clear_sessions_action' ) ) {
			delete_option( 'ssac_chat_sessions_index' );
			wp_safe_redirect( add_query_arg( array( 'page' => 'smart-site-ai-chatbot', 'tab' => 'sessions', 'ssac_msg' => 'cleared' ), admin_url( 'admin.php' ) ) );
			exit;
		}
	}

	/**
	 * Render Human-Crafted Modern SaaS Admin Dashboard (Zero Emojis)
	 */
	public static function render_admin_page() {
		$settings     = ssac_get_settings();
		$index        = SSAC_Knowledge_Indexer::get_memory_index();
		$counts       = isset( $index['counts'] ) ? $index['counts'] : array();
		$synced_at    = isset( $index['synced_at'] ) ? $index['synced_at'] : current_time( 'mysql' );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only view state: which tab to open and which notice to show.
		$active_tab   = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'appearance';
		$msg          = isset( $_GET['ssac_msg'] ) ? sanitize_key( wp_unslash( $_GET['ssac_msg'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		$sessions_log = get_option( 'ssac_chat_sessions_index', array() );
		if ( ! is_array( $sessions_log ) ) {
			$sessions_log = array();
		}

		$leads = get_posts(
			array(
				'post_type'      => 'ssac_lead',
				'posts_per_page' => 100,
				'post_status'    => 'publish',
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		?>
		<style>
			.ssac-admin-wrap { max-width: 1320px; margin: 22px 20px 48px 0; font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #0F172A; }
			.ssac-admin-wrap * { box-sizing: border-box; }
			.ssac-hero-bar {
				background: linear-gradient(135deg, #0F172A 0%, #1E1B4B 65%, #312E81 100%);
				color: #FFFFFF; border-radius: 18px; padding: 24px 28px;
				display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 20px;
				box-shadow: 0 14px 34px rgba(15, 23, 42, 0.14); margin-bottom: 20px;
				border: 1px solid rgba(255,255,255,0.08);
			}
			.ssac-hero-bar h1 { margin: 0; color: #FFFFFF; font-size: 22px; font-weight: 700; letter-spacing: -0.02em; display: flex; align-items: center; gap: 11px; }
			.ssac-hero-icon { width: 38px; height: 38px; border-radius: 10px; background: rgba(99, 102, 241, 0.25); border: 1px solid rgba(165, 180, 252, 0.35); display: inline-flex; align-items: center; justify-content: center; color: #C7D2FE; }
			.ssac-badge-status { background: rgba(16, 185, 129, 0.18); border: 1px solid rgba(16, 185, 129, 0.45); color: #6EE7B7; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 999px; letter-spacing: 0.03em; display: inline-flex; align-items: center; gap: 5px; }
			.ssac-badge-status i { width: 6px; height: 6px; border-radius: 50%; background: #10B981; display: inline-block; }
			.ssac-hero-bar p { margin: 6px 0 0; color: #CBD5E1; font-size: 13.5px; }
			.ssac-stats-strip { display: grid; grid-template-columns: repeat(auto-fit, minmax(125px, 1fr)); gap: 12px; margin-bottom: 22px; }
			.ssac-stat-card { background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 14px; padding: 14px 16px; box-shadow: 0 2px 8px rgba(15,23,42,0.03); }
			.ssac-stat-card b { display: block; font-size: 22px; font-weight: 700; color: #0F172A; line-height: 1.15; }
			.ssac-stat-card span { font-size: 11px; font-weight: 600; color: #64748B; text-transform: uppercase; letter-spacing: 0.04em; }
			.ssac-dashboard-grid { display: grid; grid-template-columns: minmax(0, 1fr) 340px; gap: 22px; align-items: start; }
			@media (max-width: 1120px) { .ssac-dashboard-grid { grid-template-columns: 1fr; } }
			.ssac-tabs { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 16px; background: #F1F5F9; padding: 5px; border-radius: 13px; border: 1px solid #E2E8F0; }
			.ssac-tab-btn { flex: 1 1 auto; justify-content: center; background: transparent; border: 0; color: #475569; padding: 10px 14px; border-radius: 9px; font-size: 13px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 7px; transition: all 0.15s ease; }
			.ssac-tab-btn:hover { color: #0F172A; background: rgba(255,255,255,0.6); }
			.ssac-tab-btn.active { background: #FFFFFF; color: #4F46E5; box-shadow: 0 2px 8px rgba(15,23,42,0.06); }
			.ssac-panel { display: none; background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 16px; padding: 26px; box-shadow: 0 6px 20px rgba(15,23,42,0.03); }
			.ssac-panel.active { display: block; }
			.ssac-panel h2 { margin: 0 0 6px; font-size: 18px; font-weight: 700; color: #0F172A; }
			.ssac-panel p.sub { margin: 0 0 20px; color: #64748B; font-size: 13px; line-height: 1.5; }
			.ssac-grid-2 { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
			@media (max-width: 782px) { .ssac-grid-2 { grid-template-columns: 1fr; } }
			.ssac-field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 15px; }
			.ssac-field label { font-size: 12.8px; font-weight: 600; color: #1E293B; display: inline-flex; align-items: center; gap: 6px; }
			.ssac-field input[type="text"], .ssac-field input[type="url"], .ssac-field input[type="email"], .ssac-field input[type="password"], .ssac-field input[type="number"], .ssac-field select, .ssac-field textarea {
				width: 100%; max-width: 100%; padding: 9px 13px; border: 1px solid #CBD5E1; border-radius: 9px; font-size: 13px; color: #0F172A; background: #F8FAFC; transition: border-color 0.15s, background 0.15s;
			}
			.ssac-field input:focus, .ssac-field select:focus, .ssac-field textarea:focus {
				outline: none; background: #FFFFFF; border-color: #4F46E5; box-shadow: 0 0 0 3px rgba(79,70,229,0.12);
			}
			.ssac-field textarea { min-height: 92px; line-height: 1.5; }
			.ssac-field small { color: #64748B; font-size: 11.5px; }
			.ssac-section-divider { margin: 22px 0 16px; padding-top: 18px; border-top: 1px solid #E2E8F0; font-size: 14px; font-weight: 700; color: #0F172A; display: flex; align-items: center; gap: 8px; }
			.ssac-btn-primary {
				background: #4F46E5; color: #FFFFFF; border: 0; border-radius: 10px;
				padding: 11px 22px; font-size: 13.5px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px;
				box-shadow: 0 4px 14px rgba(79, 70, 229, 0.25); transition: background 0.15s; text-decoration: none;
			}
			.ssac-btn-primary:hover { background: #4338CA; color: #FFFFFF; }
			.ssac-btn-sync {
				background: rgba(255,255,255,0.1); color: #FFFFFF; border: 1px solid rgba(255,255,255,0.2); border-radius: 10px;
				padding: 10px 18px; font-size: 13px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px;
				transition: background 0.15s;
			}
			.ssac-btn-sync:hover { background: rgba(255,255,255,0.18); }
			.ssac-btn-dark { background: #0F172A; color: #FFFFFF; border: 0; border-radius: 8px; padding: 8px 14px; font-size: 12px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; text-decoration: none; }
			.ssac-btn-dark:hover { background: #1E293B; color: #FFFFFF; }
			.ssac-notice { background: #ECFDF5; border: 1px solid #10B981; color: #065F46; padding: 12px 16px; border-radius: 10px; font-weight: 600; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; font-size: 13px; }
			.ssac-table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12.8px; }
			.ssac-table th, .ssac-table td { text-align: left; padding: 10px 12px; border-bottom: 1px solid #E2E8F0; vertical-align: top; }
			.ssac-table th { background: #F8FAFC; font-weight: 600; color: #334155; }
			.ssac-pill { display: inline-block; padding: 2px 8px; border-radius: 6px; font-size: 11px; font-weight: 600; }
			.ssac-pill.service { background: #EEF2FF; color: #4F46E5; }
			.ssac-pill.case_study { background: #ECFDF5; color: #059669; }
			.ssac-pill.post { background: #FEF3C7; color: #B45309; }
			.ssac-pill.page { background: #F1F5F9; color: #334155; }
			.ssac-pill.product { background: #E0F2FE; color: #0284C7; }
			/* Right Sidebar */
			.ssac-ad-sidebar { position: sticky; top: 46px; display: flex; flex-direction: column; gap: 16px; }
			.ssac-side-card { background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 14px; padding: 18px; font-size: 12.8px; color: #475569; line-height: 1.6; }
			.ssac-side-card strong.ssac-side-title { color: #0F172A; display: flex; align-items: center; gap: 7px; margin-bottom: 8px; font-size: 13.5px; }
			.ssac-side-card code { display: block; margin-top: 8px; padding: 7px 9px; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 6px; color: #4F46E5; font-weight: 600; }
			.ssac-side-card ul { margin: 8px 0 0; padding-left: 18px; }
			.ssac-side-card li { margin-bottom: 5px; }
		</style>

		<div class="ssac-admin-wrap">
			<!-- Top Hero Header -->
			<div class="ssac-hero-bar">
				<div>
					<h1>
						<span class="ssac-hero-icon"><?php echo self::svg_icon( 'bot', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<span>Smart Site AI Chatbot</span>
						<span class="ssac-badge-status"><i></i> <?php esc_html_e( 'Active', 'smart-site-ai-chatbot' ); ?></span>
					</h1>
					<p><?php esc_html_e( 'Answers from your own content, lead capture and booking, and WooCommerce order lookup.', 'smart-site-ai-chatbot' ); ?></p>
				</div>
				<form method="post" style="margin:0">
					<?php wp_nonce_field( 'ssac_sync_memory_action', 'ssac_sync_memory_nonce' ); ?>
					<button type="submit" class="ssac-btn-sync">
						<?php echo self::svg_icon( 'sync', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span>Re-Sync Site Memory</span>
					</button>
				</form>
			</div>

			<?php if ( 'saved' === $msg ) : ?>
				<div class="ssac-notice"><?php echo self::svg_icon( 'check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <span>Settings saved and Site Memory synchronized.</span></div>
			<?php elseif ( 'synced' === $msg ) : ?>
				<div class="ssac-notice"><?php echo self::svg_icon( 'sync', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <span>Full Site Memory re-indexed across all pages, services, products, case studies, and FAQs.</span></div>
			<?php elseif ( 'deleted' === $msg ) : ?>
				<div class="ssac-notice"><?php echo self::svg_icon( 'trash', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <span>Entry deleted.</span></div>
			<?php elseif ( 'cleared' === $msg ) : ?>
				<div class="ssac-notice"><?php echo self::svg_icon( 'check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <span>Recent visitor chat sessions log cleared.</span></div>
			<?php endif; ?>

			<!-- Live Memory Counter Cards -->
			<div class="ssac-stats-strip">
				<div class="ssac-stat-card"><b><?php echo (int) ( $counts['services'] ?? 0 ); ?></b><span>Services</span></div>
				<div class="ssac-stat-card"><b><?php echo (int) ( $counts['pages'] ?? 0 ); ?></b><span>Pages</span></div>
				<div class="ssac-stat-card"><b><?php echo (int) ( $counts['case_studies'] ?? 0 ); ?></b><span>Case Studies</span></div>
				<div class="ssac-stat-card"><b><?php echo (int) ( $counts['posts'] ?? 0 ); ?></b><span>Blog Posts</span></div>
				<div class="ssac-stat-card"><b><?php echo (int) ( $counts['products'] ?? 0 ); ?></b><span>Products</span></div>
				<div class="ssac-stat-card"><b><?php echo (int) ( $counts['faqs'] ?? 0 ); ?></b><span>FAQs</span></div>
				<div class="ssac-stat-card"><b><?php echo count( $sessions_log ); ?></b><span>Active Sessions</span></div>
				<div class="ssac-stat-card"><b><?php echo count( $leads ); ?></b><span>Leads &amp; Bookings</span></div>
			</div>

			<div class="ssac-dashboard-grid">
				<!-- LEFT MAIN SETTINGS AREA -->
				<div class="ssac-main-col">
					<div class="ssac-tabs">
						<button type="button" class="ssac-tab-btn <?php echo 'appearance' === $active_tab ? 'active' : ''; ?>" data-tab="appearance">
							<?php echo self::svg_icon( 'sliders', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span>Appearance &amp; Features</span>
						</button>
						<button type="button" class="ssac-tab-btn <?php echo 'api' === $active_tab ? 'active' : ''; ?>" data-tab="api">
							<?php echo self::svg_icon( 'cpu', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span>Free &amp; Paid AI API</span>
						</button>
						<button type="button" class="ssac-tab-btn <?php echo 'memory' === $active_tab ? 'active' : ''; ?>" data-tab="memory">
							<?php echo self::svg_icon( 'database', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span>Site Memory</span>
						</button>
						<button type="button" class="ssac-tab-btn <?php echo 'sessions' === $active_tab ? 'active' : ''; ?>" data-tab="sessions">
							<?php echo self::svg_icon( 'history', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span>Chat Sessions (<?php echo count( $sessions_log ); ?>)</span>
						</button>
						<button type="button" class="ssac-tab-btn <?php echo 'leads' === $active_tab ? 'active' : ''; ?>" data-tab="leads">
							<?php echo self::svg_icon( 'calendar', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span>Bookings &amp; Leads (<?php echo count( $leads ); ?>)</span>
						</button>
					</div>

					<form method="post">
						<?php wp_nonce_field( 'ssac_save_settings_action', 'ssac_save_settings_nonce' ); ?>

						<!-- TAB 1: APPEARANCE, PERSISTENT SESSION & 7 FEATURES -->
						<div class="ssac-panel <?php echo 'appearance' === $active_tab ? 'active' : ''; ?>" id="ssac-tab-appearance">
							<h2><?php esc_html_e( 'Appearance, sessions and features', 'smart-site-ai-chatbot' ); ?></h2>
							<p class="sub"><?php esc_html_e( 'How the assistant looks, how long a visitor conversation is kept, and which features are available in chat.', 'smart-site-ai-chatbot' ); ?></p>

							<div class="ssac-grid-2">
								<div class="ssac-field">
									<label><input type="checkbox" name="enabled" value="1" <?php checked( $settings['enabled'], '1' ); ?>> <strong>Enable Floating Assistant on Frontend</strong></label>
									<small>Displays the floating assistant across your website, or use <code>[smart_site_ai_chatbot]</code> on any page.</small>
								</div>
								<div class="ssac-field">
									<label>Floating Screen Position</label>
									<select name="position">
										<option value="right" <?php selected( $settings['position'], 'right' ); ?>>Bottom Right (Default)</option>
										<option value="left" <?php selected( $settings['position'], 'left' ); ?>>Bottom Left</option>
									</select>
								</div>

								<div class="ssac-field">
									<label>Assistant Display Name</label>
									<input type="text" name="bot_name" value="<?php echo esc_attr( $settings['bot_name'] ); ?>" placeholder="Smart Site Assistant">
								</div>
								<div class="ssac-field">
									<label>Header Status / Subtitle</label>
									<input type="text" name="bot_subtitle" value="<?php echo esc_attr( $settings['bot_subtitle'] ); ?>" placeholder="Online · Instant Site Assistant">
								</div>

								<div class="ssac-field">
									<label>Assistant Avatar Image URL (Optional)</label>
									<div style="display:flex;gap:8px">
										<input type="url" name="bot_avatar" id="ssac_bot_avatar" value="<?php echo esc_attr( $settings['bot_avatar'] ); ?>" placeholder="Leave empty for clean SVG icon">
										<button type="button" class="ssac-btn-dark ssac-upload-btn" data-target="ssac_bot_avatar">Upload</button>
									</div>
								</div>

								<div class="ssac-field">
									<label>Floating Launcher SVG Icon Style</label>
									<select name="launcher_icon">
										<option value="chat" <?php selected( $settings['launcher_icon'], 'chat' ); ?>>Message Bubble Vector Icon (Recommended)</option>
										<option value="sparkles" <?php selected( $settings['launcher_icon'], 'sparkles' ); ?>>Minimal Sparkle Vector Icon</option>
										<option value="robot" <?php selected( $settings['launcher_icon'], 'robot' ); ?>>Geometric Assistant Vector Icon</option>
										<option value="bolt" <?php selected( $settings['launcher_icon'], 'bolt' ); ?>>Instant Lightning Vector Icon</option>
										<option value="custom" <?php selected( $settings['launcher_icon'], 'custom' ); ?>>Custom Uploaded Image</option>
									</select>
								</div>

								<div class="ssac-field">
									<label>Custom Launcher Icon Image URL</label>
									<div style="display:flex;gap:8px">
										<input type="url" name="launcher_custom_img" id="ssac_launcher_img" value="<?php echo esc_attr( $settings['launcher_custom_img'] ); ?>" placeholder="https://...">
										<button type="button" class="ssac-btn-dark ssac-upload-btn" data-target="ssac_launcher_img">Upload</button>
									</div>
								</div>

								<div class="ssac-field">
									<label>Default Chat Window Theme</label>
									<select name="theme_mode">
										<option value="light" <?php selected( $settings['theme_mode'], 'light' ); ?>>Light Mode (Clean SaaS Default)</option>
										<option value="dark" <?php selected( $settings['theme_mode'], 'dark' ); ?>>Dark Slate Mode</option>
									</select>
								</div>

								<div class="ssac-field">
									<label>Primary Brand Color</label>
									<input type="text" name="primary_color" value="<?php echo esc_attr( $settings['primary_color'] ); ?>" placeholder="#4F46E5">
								</div>

								<div class="ssac-field">
									<label>Secondary Accent Color</label>
									<input type="text" name="accent_color" value="<?php echo esc_attr( $settings['accent_color'] ); ?>" placeholder="#4338CA">
								</div>
							</div>

							<div class="ssac-field">
								<label>Welcome Greeting Message</label>
								<textarea name="welcome_message" rows="3"><?php echo esc_textarea( $settings['welcome_message'] ); ?></textarea>
							</div>

							<div class="ssac-field">
								<label><?php esc_html_e( 'Quick actions and starter prompts', 'smart-site-ai-chatbot' ); ?></label>
								<textarea name="demo_prompts" rows="4" placeholder="<?php esc_attr_e( 'Leave empty to generate these from your site content', 'smart-site-ai-chatbot' ); ?>"><?php echo esc_textarea( $settings['demo_prompts'] ); ?></textarea>
								<small>
									<?php esc_html_e( 'Leave this empty and the assistant builds its own buttons from what it finds on your site: products and your busiest product categories on a store, services and portfolio on an agency site, articles on a blog. Enter one prompt per line to override them.', 'smart-site-ai-chatbot' ); ?>
								</small>
								<?php
								$ssac_auto_actions = array();

								foreach ( SSAC_Frontend_Widget::get_quick_actions() as $ssac_action ) {
									$ssac_auto_actions[] = $ssac_action['label'];
								}
								?>
								<small style="color:#4F46E5;font-weight:600">
									<?php
									printf(
										/* translators: %s: comma separated list of button labels. */
										esc_html__( 'Currently generated for this site: %s', 'smart-site-ai-chatbot' ),
										esc_html( implode( ', ', $ssac_auto_actions ) )
									);
									?>
								</small>
							</div>

							<div class="ssac-section-divider">
								<?php echo self::svg_icon( 'history', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span>Persistent Chat Memory (IP + Browser) &amp; Smart Capabilities</span>
							</div>

							<div class="ssac-grid-2">
								<div class="ssac-field">
									<label>Chat History Retention Time (IP + Browser Session)</label>
									<select name="session_ttl_hours">
										<option value="6" <?php selected( $settings['session_ttl_hours'] ?? '24', '6' ); ?>>6 Hours</option>
										<option value="12" <?php selected( $settings['session_ttl_hours'] ?? '24', '12' ); ?>>12 Hours</option>
										<option value="24" <?php selected( $settings['session_ttl_hours'] ?? '24', '24' ); ?>>24 Hours (Recommended Default)</option>
										<option value="48" <?php selected( $settings['session_ttl_hours'] ?? '24', '48' ); ?>>48 Hours (2 Days)</option>
										<option value="168" <?php selected( $settings['session_ttl_hours'] ?? '24', '168' ); ?>>7 Days</option>
									</select>
									<small>Preserves visitor chat history across page reloads and navigation until expired or reset.</small>
								</div>

								<div class="ssac-field">
									<label>Per-IP Anti-Spam Rate Limit (Messages / Minute)</label>
									<input type="number" name="rate_limit_per_min" min="3" max="120" value="<?php echo esc_attr( $settings['rate_limit_per_min'] ?? '15' ); ?>">
									<small>Protects your AI API quota and server from automated spam.</small>
								</div>

								<div class="ssac-field">
									<label>Smart Context &amp; Commerce Features</label>
									<label><input type="checkbox" name="enable_page_aware" value="1" <?php checked( $settings['enable_page_aware'] ?? '1', '1' ); ?>> Enable Page-Aware Smart Greeting &amp; Prompts</label>
									<label><input type="checkbox" name="enable_woo_order_lookup" value="1" <?php checked( $settings['enable_woo_order_lookup'] ?? '1', '1' ); ?>> Enable WooCommerce Live Order Status Lookup</label>
									<label><input type="checkbox" name="enable_whatsapp_handoff" value="1" <?php checked( $settings['enable_whatsapp_handoff'] ?? '0', '1' ); ?>> Enable One-Click WhatsApp &amp; Human Support Handoff</label>
								</div>

								<div class="ssac-field">
									<label>WhatsApp Handoff Number (With Country Code)</label>
									<input type="text" name="whatsapp_number" value="<?php echo esc_attr( $settings['whatsapp_number'] ?? '' ); ?>" placeholder="+1 555 010 1234">
									<small>Used when a visitor asks to speak with a human specialist.</small>
								</div>

								<div class="ssac-field">
									<label>Floating Welcome Tooltip Text</label>
									<input type="text" name="tooltip_text" value="<?php echo esc_attr( $settings['tooltip_text'] ); ?>">
									<label style="margin-top:4px"><input type="checkbox" name="show_tooltip" value="1" <?php checked( $settings['show_tooltip'], '1' ); ?>> Show greeting tooltip next to launcher</label>
								</div>

								<div class="ssac-field">
									<label>Interactive &amp; Privacy Options</label>
									<label><input type="checkbox" name="enable_voice" value="1" <?php checked( $settings['enable_voice'], '1' ); ?>> <?php echo self::svg_icon( 'mic', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> Voice Input (Browser Speech-to-Text)</label>
									<label><input type="checkbox" name="enable_sound" value="1" <?php checked( $settings['enable_sound'], '1' ); ?>> <?php echo self::svg_icon( 'bell', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> Subtle Notification Sound</label>
									<label><input type="checkbox" name="enable_gdpr_consent" value="1" <?php checked( $settings['enable_gdpr_consent'] ?? '0', '1' ); ?>> <?php echo self::svg_icon( 'shield', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> Show GDPR Privacy Consent Notice</label>
									<label><input type="checkbox" name="show_credit_link" value="1" <?php checked( $settings['show_credit_link'] ?? '0', '1' ); ?>> <?php esc_html_e( 'Show a small credit link to your business in the chat footer', 'smart-site-ai-chatbot' ); ?></label>
								</div>
							</div>

							<div class="ssac-field">
								<label>GDPR Consent Text (Shown when GDPR toggle is enabled)</label>
								<input type="text" name="gdpr_consent_text" value="<?php echo esc_attr( $settings['gdpr_consent_text'] ?? '' ); ?>">
							</div>

							<button type="submit" class="ssac-btn-primary">
								<?php echo self::svg_icon( 'save', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span>Save Appearance &amp; Feature Settings</span>
							</button>
						</div>

						<!-- TAB 2: AI API KEYS -->
						<div class="ssac-panel <?php echo 'api' === $active_tab ? 'active' : ''; ?>" id="ssac-tab-api">
							<h2>Free &amp; Paid AI API Configuration</h2>
							<p class="sub">Run 100% free out-of-the-box using the Built-in Smart Local RAG Engine, or connect a free/paid API key from Google Gemini, OpenAI, OpenRouter, or Groq.</p>

							<div class="ssac-field">
								<label>Active AI Brain Mode</label>
								<select name="ai_provider">
									<option value="auto" <?php selected( $settings['ai_provider'], 'auto' ); ?>>Auto-Detect (Uses API Key if entered, otherwise Built-in Free Local RAG Engine)</option>
									<option value="gemini" <?php selected( $settings['ai_provider'], 'gemini' ); ?>>Google Gemini API (Free &amp; Paid Google AI Studio Keys)</option>
									<option value="openai" <?php selected( $settings['ai_provider'], 'openai' ); ?>>OpenAI API (ChatGPT — gpt-4o-mini / gpt-4o)</option>
									<option value="openrouter" <?php selected( $settings['ai_provider'], 'openrouter' ); ?>>OpenRouter API (Free &amp; Paid Models)</option>
									<option value="groq" <?php selected( $settings['ai_provider'], 'groq' ); ?>>Groq Cloud API (High-Speed Free &amp; Paid Llama Models)</option>
									<option value="local" <?php selected( $settings['ai_provider'], 'local' ); ?>>Built-in Local Smart RAG Engine Only (100% Free — No API Key Needed)</option>
								</select>
							</div>

							<div class="ssac-grid-2">
								<div class="ssac-field">
									<label>Google Gemini API Key (Free or Paid)</label>
									<input type="password" name="gemini_api_key" value="<?php echo esc_attr( $settings['gemini_api_key'] ); ?>" placeholder="AIzaSy...">
									<small>Get a free API key at <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener">Google AI Studio</a>.</small>
								</div>
								<div class="ssac-field">
									<label>Google Gemini Model</label>
									<input type="text" name="gemini_model" value="<?php echo esc_attr( $settings['gemini_model'] ); ?>" placeholder="gemini-2.5-flash">
								</div>

								<div class="ssac-field">
									<label>OpenAI API Key</label>
									<input type="password" name="openai_api_key" value="<?php echo esc_attr( $settings['openai_api_key'] ); ?>" placeholder="sk-...">
								</div>
								<div class="ssac-field">
									<label>OpenAI Model</label>
									<input type="text" name="openai_model" value="<?php echo esc_attr( $settings['openai_model'] ); ?>" placeholder="gpt-4o-mini">
								</div>

								<div class="ssac-field">
									<label>OpenRouter API Key (Free Models Supported)</label>
									<input type="password" name="openrouter_api_key" value="<?php echo esc_attr( $settings['openrouter_api_key'] ); ?>" placeholder="sk-or-v1-...">
								</div>
								<div class="ssac-field">
									<label>OpenRouter Model</label>
									<input type="text" name="openrouter_model" value="<?php echo esc_attr( $settings['openrouter_model'] ); ?>" placeholder="meta-llama/llama-3.3-70b-instruct:free">
								</div>

								<div class="ssac-field">
									<label>Groq API Key (Free Tier Supported)</label>
									<input type="password" name="groq_api_key" value="<?php echo esc_attr( $settings['groq_api_key'] ); ?>" placeholder="gsk_...">
								</div>
								<div class="ssac-field">
									<label>Groq Model</label>
									<input type="text" name="groq_model" value="<?php echo esc_attr( $settings['groq_model'] ); ?>" placeholder="llama-3.3-70b-versatile">
								</div>
							</div>

							<div class="ssac-field">
								<label>System Prompt / AI Instructions</label>
								<textarea name="system_instructions" rows="3"><?php echo esc_textarea( $settings['system_instructions'] ); ?></textarea>
							</div>

							<button type="submit" class="ssac-btn-primary">
								<?php echo self::svg_icon( 'save', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span>Save AI API Settings</span>
							</button>
						</div>

						<!-- TAB 3: SITE MEMORY & BUSINESS INFO -->
						<div class="ssac-panel <?php echo 'memory' === $active_tab ? 'active' : ''; ?>" id="ssac-tab-memory">
							<h2>Site Memory &amp; Business Profile</h2>
							<p class="sub">Last synchronized: <strong><?php echo esc_html( $synced_at ); ?></strong>. Automatically indexes published Pages, Services, Products, Case Studies, Posts, and FAQs.</p>

							<div class="ssac-grid-2">
								<div class="ssac-field">
									<label>Business / Agency Name</label>
									<input type="text" name="business_name" value="<?php echo esc_attr( $settings['business_name'] ); ?>" placeholder="Your business name">
								</div>
								<div class="ssac-field">
									<label>Main Website URL</label>
									<input type="url" name="business_website" value="<?php echo esc_attr( $settings['business_website'] ); ?>" placeholder="https://example.com">
								</div>
								<div class="ssac-field">
									<label>Lead Notification &amp; Contact Email</label>
									<input type="email" name="business_email" value="<?php echo esc_attr( $settings['business_email'] ); ?>" placeholder="you@example.com">
								</div>
								<div class="ssac-field">
									<label>Phone / WhatsApp Number</label>
									<input type="text" name="business_phone" value="<?php echo esc_attr( $settings['business_phone'] ); ?>" placeholder="+1 555 010 1234">
								</div>
								<div class="ssac-field">
									<label>Working Hours</label>
									<input type="text" name="business_hours" value="<?php echo esc_attr( $settings['business_hours'] ); ?>">
								</div>
								<div class="ssac-field">
									<label>Direct Booking / Portfolio URL</label>
									<input type="url" name="booking_url" value="<?php echo esc_attr( $settings['booking_url'] ); ?>">
								</div>
							</div>

							<div class="ssac-field">
								<label>Custom Knowledge Base / Pricing / Policies (Memorized by Assistant)</label>
								<textarea name="custom_knowledge" rows="4"><?php echo esc_textarea( $settings['custom_knowledge'] ); ?></textarea>
							</div>

							<button type="submit" class="ssac-btn-primary">
								<?php echo self::svg_icon( 'save', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span>Save &amp; Sync Memory</span>
							</button>

							<h3 style="margin:26px 0 10px;font-size:15px">Indexed Website Content (<?php echo count( $index['items'] ?? array() ); ?> Items)</h3>
							<div style="max-height:340px;overflow:auto;border:1px solid #E2E8F0;border-radius:10px">
								<table class="ssac-table" style="margin:0">
									<thead>
										<tr>
											<th>Title</th>
											<th>Type</th>
											<th>Category</th>
											<th>Link</th>
										</tr>
									</thead>
									<tbody>
										<?php foreach ( ( $index['items'] ?? array() ) as $it ) : ?>
											<tr>
												<td><strong><?php echo esc_html( $it['title'] ); ?></strong></td>
												<td><span class="ssac-pill <?php echo esc_attr( $it['type'] ); ?>"><?php echo esc_html( $it['type'] ); ?></span></td>
												<td><?php echo esc_html( $it['category'] ); ?></td>
												<td><a href="<?php echo esc_url( $it['url'] ); ?>" target="_blank" rel="noopener">View</a></td>
											</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
							</div>
						</div>
					</form>

					<!-- TAB 4: CHAT SESSIONS VIEWER (Feature 6) -->
					<div class="ssac-panel <?php echo 'sessions' === $active_tab ? 'active' : ''; ?>" id="ssac-tab-sessions">
						<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:14px">
							<div>
								<h2>Visitor Chat Sessions (IP + Browser Memory)</h2>
								<p class="sub" style="margin:0">Active sessions are persisted for <strong><?php echo (int) ( $settings['session_ttl_hours'] ?? 24 ); ?> hours</strong> so visitors never lose their chat when navigating pages.</p>
							</div>
							<?php if ( ! empty( $sessions_log ) ) : ?>
								<form method="post" style="margin:0">
									<?php wp_nonce_field( 'ssac_clear_sessions_action', 'ssac_clear_sessions_nonce' ); ?>
									<button type="submit" class="ssac-btn-dark">
										<?php echo self::svg_icon( 'trash', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										<span>Clear Session Logs</span>
									</button>
								</form>
							<?php endif; ?>
						</div>

						<?php if ( empty( $sessions_log ) ) : ?>
							<p style="color:#64748B;font-size:13.5px">No visitor chat sessions recorded yet. Send a message in the frontend chat widget to see live session tracking here.</p>
						<?php else : ?>
							<table class="ssac-table">
								<thead>
									<tr>
										<th>Visitor IP (Masked)</th>
										<th>Last Active Page</th>
										<th>Messages</th>
										<th>Latest Exchange</th>
										<th>Updated</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ( $sessions_log as $s_item ) : ?>
										<tr>
											<td><code><?php echo esc_html( $s_item['ip_masked'] ?? '127.0.0.xxx' ); ?></code></td>
											<td>
												<?php if ( ! empty( $s_item['last_url'] ) ) : ?>
													<a href="<?php echo esc_url( $s_item['last_url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( ! empty( $s_item['page_title'] ) ? $s_item['page_title'] : $s_item['last_url'] ); ?></a>
												<?php else : ?>
													<span>Homepage</span>
												<?php endif; ?>
											</td>
											<td><strong><?php echo (int) ( $s_item['msg_count'] ?? 0 ); ?></strong></td>
											<td style="max-width:300px;color:#334155"><?php echo esc_html( $s_item['last_msg'] ?? '' ); ?></td>
											<td><?php echo esc_html( $s_item['updated_at'] ?? '' ); ?></td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						<?php endif; ?>
					</div>

					<!-- TAB 5: BOOKINGS, FORM LEADS & SUBSCRIBERS + CSV EXPORT -->
					<div class="ssac-panel <?php echo 'leads' === $active_tab ? 'active' : ''; ?>" id="ssac-tab-leads">
						<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:14px">
							<div>
								<h2>Bookings, Project Inquiries &amp; Subscribers</h2>
								<?php $ssac_notify_to = ! empty( $settings['business_email'] ) ? $settings['business_email'] : get_option( 'admin_email' ); ?>
								<p class="sub" style="margin:0">
									<?php
									printf(
										/* translators: %s: email address that receives the notifications. */
										esc_html__( 'Every booking, inquiry and signup captured in chat is saved here and emailed to %s.', 'smart-site-ai-chatbot' ),
										'<strong>' . esc_html( $ssac_notify_to ) . '</strong>'
									);
									?>
								</p>
							</div>
							<?php if ( ! empty( $leads ) ) : ?>
								<?php
								$csv_url = wp_nonce_url(
									add_query_arg(
										array(
											'page'            => 'smart-site-ai-chatbot',
											'ssac_export_csv' => '1',
										),
										admin_url( 'admin.php' )
									),
									'ssac_export_csv_action'
								);
								?>
								<a href="<?php echo esc_url( $csv_url ); ?>" class="ssac-btn-primary">
									<?php echo self::svg_icon( 'download', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<span>Export CSV</span>
								</a>
							<?php endif; ?>
						</div>

						<?php if ( empty( $leads ) ) : ?>
							<p style="color:#64748B;font-size:13.5px">No bookings or leads submitted yet. Test the frontend chat by clicking "Book Call" or "Inquiry".</p>
						<?php else : ?>
							<table class="ssac-table">
								<thead>
									<tr>
										<th>Date</th>
										<th>Submission</th>
										<th>Details</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ( $leads as $ld ) : ?>
										<?php
										$del_url = wp_nonce_url(
											add_query_arg(
												array(
													'page'             => 'smart-site-ai-chatbot',
													'tab'              => 'leads',
													'ssac_delete_lead' => $ld->ID,
												),
												admin_url( 'admin.php' )
											),
											'ssac_delete_lead_action'
										);
										?>
										<tr>
											<td style="white-space:nowrap"><?php echo esc_html( get_the_date( 'M j, Y g:i A', $ld ) ); ?></td>
											<td><strong><?php echo esc_html( $ld->post_title ); ?></strong></td>
											<td><pre style="margin:0;white-space:pre-wrap;font-family:inherit;font-size:12px;color:#334155"><?php echo esc_html( $ld->post_content ); ?></pre></td>
											<td><a href="<?php echo esc_url( $del_url ); ?>" style="color:#DC2626;font-weight:600;text-decoration:none" onclick="return confirm('Delete this entry?');">Delete</a></td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						<?php endif; ?>
					</div>
				</div>

				<aside class="ssac-ad-sidebar">
					<div class="ssac-side-card">
						<strong class="ssac-side-title">
							<?php echo self::svg_icon( 'code', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static inline SVG markup. ?>
							<span><?php esc_html_e( 'Shortcode and block', 'smart-site-ai-chatbot' ); ?></span>
						</strong>
						<?php esc_html_e( 'Embed an inline assistant launcher in any page, post or template:', 'smart-site-ai-chatbot' ); ?>
						<code>[smart_site_ai_chatbot]</code>
						<?php esc_html_e( 'The same card is available as the Smart Site AI Chatbot block in the editor.', 'smart-site-ai-chatbot' ); ?>
					</div>

					<div class="ssac-side-card">
						<strong class="ssac-side-title">
							<?php echo self::svg_icon( 'shield', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static inline SVG markup. ?>
							<span><?php esc_html_e( 'Privacy and data', 'smart-site-ai-chatbot' ); ?></span>
						</strong>
						<ul>
							<li><?php esc_html_e( 'Nothing leaves your site unless you add an API key.', 'smart-site-ai-chatbot' ); ?></li>
							<li><?php esc_html_e( 'Chat sessions are stored as temporary records and expire automatically.', 'smart-site-ai-chatbot' ); ?></li>
							<li><?php esc_html_e( 'Visitor IP addresses are only ever shown masked.', 'smart-site-ai-chatbot' ); ?></li>
							<li><?php esc_html_e( 'Deleting the plugin removes its settings, sessions and leads.', 'smart-site-ai-chatbot' ); ?></li>
						</ul>
					</div>

					<div class="ssac-side-card">
						<strong class="ssac-side-title">
							<?php echo self::svg_icon( 'bot', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static inline SVG markup. ?>
							<span><?php esc_html_e( 'Getting started', 'smart-site-ai-chatbot' ); ?></span>
						</strong>
						<ul>
							<li><?php esc_html_e( 'Set your assistant name, colours and position.', 'smart-site-ai-chatbot' ); ?></li>
							<li><?php esc_html_e( 'Fill in your business profile so the assistant can share contact details.', 'smart-site-ai-chatbot' ); ?></li>
							<li><?php esc_html_e( 'Add an API key only if you want generated answers.', 'smart-site-ai-chatbot' ); ?></li>
						</ul>
					</div>
				</aside>
			</div>
		</div>

		<script>
		(function(){
			var tabs = document.querySelectorAll('.ssac-tab-btn');
			var panels = document.querySelectorAll('.ssac-panel');
			tabs.forEach(function(btn){
				btn.addEventListener('click', function(){
					var t = btn.getAttribute('data-tab');
					tabs.forEach(function(b){ b.classList.remove('active'); });
					panels.forEach(function(p){ p.classList.remove('active'); });
					btn.classList.add('active');
					var target = document.getElementById('ssac-tab-' + t);
					if(target) target.classList.add('active');
				});
			});

			document.querySelectorAll('.ssac-upload-btn').forEach(function(button){
				button.addEventListener('click', function(e){
					e.preventDefault();
					var targetId = button.getAttribute('data-target');
					var input = document.getElementById(targetId);
					if(!window.wp || !wp.media) return;
					var frame = wp.media({ title: 'Select Image', multiple: false });
					frame.on('select', function(){
						var attachment = frame.state().get('selection').first().toJSON();
						if(input && attachment.url) input.value = attachment.url;
					});
					frame.open();
				});
			});
		})();
		</script>
		<?php
	}
}
