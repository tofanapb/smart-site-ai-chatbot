<?php
/**
 * Frontend widget.
 *
 * Renders the floating assistant, the page-aware starter prompts, the
 * `[smart_site_ai_chatbot]` shortcode and the matching block.
 *
 * @package Smart_Site_AI_Chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Frontend output and asset loading.
 */
class SSAC_Frontend_Widget {

	/**
	 * Guard against double initialisation.
	 *
	 * @var bool
	 */
	private static $initialized = false;

	/**
	 * Whether the widget markup has already been printed.
	 *
	 * @var bool
	 */
	private static $rendered = false;

	/**
	 * Whether the widget assets were queued on this request.
	 *
	 * @var bool
	 */
	private static $enqueued = false;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		if ( self::$initialized ) {
			return;
		}
		self::$initialized = true;

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );

		/*
		 * Priority 5 matters: footer scripts print at priority 20, so the markup
		 * has to exist before the controller script runs.
		 */
		add_action( 'wp_footer', array( __CLASS__, 'render_widget' ), 5 );

		add_shortcode( 'smart_site_ai_chatbot', array( __CLASS__, 'render_shortcode' ) );
		add_action( 'init', array( __CLASS__, 'register_block' ) );
	}

	/**
	 * Whether the widget should load on the current request.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		$settings = ssac_get_settings();

		if ( '1' !== $settings['enabled'] ) {
			return false;
		}

		/**
		 * Filter whether the chat widget loads on the current request.
		 *
		 * @param bool $enabled Whether to load the widget.
		 */
		return (bool) apply_filters( 'ssac_enable_widget', true );
	}

	/**
	 * Page-aware greeting and starter prompts.
	 *
	 * @param array $settings Plugin settings.
	 * @return array
	 */
	public static function get_page_aware_context( $settings ) {
		// An empty setting means "work it out from the site content".
		$default_prompts = array_values(
			array_filter(
				array_map( 'trim', explode( "\n", (string) $settings['demo_prompts'] ) )
			)
		);

		if ( empty( $default_prompts ) ) {
			foreach ( self::get_quick_actions() as $action ) {
				$default_prompts[] = $action['prompt'];
			}
		}

		$context = array(
			'type'     => 'general',
			'badge'    => __( 'Site assistant', 'smart-site-ai-chatbot' ),
			'greeting' => $settings['welcome_message'],
			'prompts'  => $default_prompts,
		);

		if ( isset( $settings['enable_page_aware'] ) && '1' !== $settings['enable_page_aware'] ) {
			return $context;
		}

		$is_shop = ( function_exists( 'is_woocommerce' ) && is_woocommerce() )
			|| ( function_exists( 'is_cart' ) && is_cart() )
			|| ( function_exists( 'is_checkout' ) && is_checkout() );

		if ( $is_shop ) {
			$context['type']     = 'shop';
			$context['badge']    = __( 'Store assistant', 'smart-site-ai-chatbot' );
			$context['greeting'] = __( 'Need help finding the right product, checking details, or tracking an order? Ask me below.', 'smart-site-ai-chatbot' );
			$context['prompts']  = array(
				__( 'Track my order', 'smart-site-ai-chatbot' ),
				__( 'Show me your products', 'smart-site-ai-chatbot' ),
				__( 'Contact support', 'smart-site-ai-chatbot' ),
			);

			return $context;
		}

		if ( ! is_singular() ) {
			return $context;
		}

		$post_id = get_queried_object_id();

		if ( ! $post_id ) {
			return $context;
		}

		$slug  = (string) get_post_field( 'post_name', $post_id );
		$title = get_the_title( $post_id );

		if ( false !== strpos( $slug, 'contact' ) ) {
			$context['type']     = 'contact';
			$context['badge']    = __( 'Instant concierge', 'smart-site-ai-chatbot' );
			$context['greeting'] = __( 'Prefer not to fill in a form? I can take your inquiry or book a call right here in chat.', 'smart-site-ai-chatbot' );
			$context['prompts']  = array(
				__( 'Book a consultation call', 'smart-site-ai-chatbot' ),
				__( 'Submit a project inquiry', 'smart-site-ai-chatbot' ),
				__( 'Contact support', 'smart-site-ai-chatbot' ),
			);
		} elseif ( false !== strpos( $slug, 'pricing' ) || false !== strpos( $slug, 'plan' ) || false !== strpos( $slug, 'package' ) ) {
			$context['type']     = 'pricing';
			$context['badge']    = __( 'Pricing advisor', 'smart-site-ai-chatbot' );
			$context['greeting'] = __( 'Comparing options? Tell me about your project and I will point you to the right one.', 'smart-site-ai-chatbot' );
			$context['prompts']  = array(
				__( 'Which option fits my project?', 'smart-site-ai-chatbot' ),
				__( 'Book a consultation call', 'smart-site-ai-chatbot' ),
				__( 'Submit a project inquiry', 'smart-site-ai-chatbot' ),
			);
		} elseif ( false !== strpos( $slug, 'case-stud' ) || false !== strpos( $slug, 'portfolio' ) || is_singular( array( 'case_study', 'portfolio' ) ) ) {
			$context['type']     = 'portfolio';
			$context['badge']    = __( 'Portfolio guide', 'smart-site-ai-chatbot' );
			$context['greeting'] = __( 'Reviewing our work? Ask me for examples in your industry, or start an inquiry.', 'smart-site-ai-chatbot' );
			$context['prompts']  = array(
				__( 'Show me your case studies', 'smart-site-ai-chatbot' ),
				__( 'Book a consultation call', 'smart-site-ai-chatbot' ),
				__( 'Submit a project inquiry', 'smart-site-ai-chatbot' ),
			);
		} elseif ( is_singular( 'service' ) ) {
			$context['type']  = 'service';
			$context['badge'] = __( 'Solutions specialist', 'smart-site-ai-chatbot' );

			if ( $title ) {
				/* translators: %s: page title. */
				$context['greeting'] = sprintf( __( 'Have questions about %s, what is included, or timelines? Ask me anything.', 'smart-site-ai-chatbot' ), $title );
			}

			$context['prompts'] = array(
				__( 'Book a consultation call', 'smart-site-ai-chatbot' ),
				__( 'Submit a project inquiry', 'smart-site-ai-chatbot' ),
				__( 'Show me your case studies', 'smart-site-ai-chatbot' ),
			);
		}

		return $context;
	}

	/**
	 * Build the configuration object handed to the controller script.
	 *
	 * @param array $settings Plugin settings.
	 * @return array
	 */
	public static function get_frontend_config( $settings ) {
		$page_context = self::get_page_aware_context( $settings );

		$wa_digits = preg_replace( '/[^0-9]/', '', (string) ( ! empty( $settings['whatsapp_number'] ) ? $settings['whatsapp_number'] : '' ) );
		$wa_url    = $wa_digits
			? 'https://wa.me/' . $wa_digits . '?text=' . rawurlencode( __( 'Hello, I am visiting your website and have a question.', 'smart-site-ai-chatbot' ) )
			: '';

		return array(
			'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
			'restUrl'         => esc_url_raw( rest_url( 'ssac/v1/chat' ) ),
			'nonce'           => wp_create_nonce( SSAC_Chat_Engine::NONCE_ACTION ),
			'botName'         => $settings['bot_name'],
			'welcomeMessage'  => $page_context['greeting'],
			'defaultGreeting' => $settings['welcome_message'],
			'demoPrompts'     => array_slice( $page_context['prompts'], 0, 4 ),
			'enableVoice'     => '1' === $settings['enable_voice'],
			'enableSound'     => '1' === $settings['enable_sound'],
			'enableWhatsapp'  => isset( $settings['enable_whatsapp_handoff'] ) && '1' === $settings['enable_whatsapp_handoff'],
			'whatsappUrl'     => $wa_url,
			'enableGdpr'      => isset( $settings['enable_gdpr_consent'] ) && '1' === $settings['enable_gdpr_consent'],
			'sessionTtlHours' => isset( $settings['session_ttl_hours'] ) ? (int) $settings['session_ttl_hours'] : 24,
			'maxMessageLen'   => SSAC_Chat_Engine::MAX_MESSAGE_LEN,
			'i18n'            => array(
				'greetingFallback' => __( 'Hello. How can I help you today?', 'smart-site-ai-chatbot' ),
				'genericError'     => __( 'Something went wrong. Please try again.', 'smart-site-ai-chatbot' ),
				'networkError'     => __( 'Connection error. Please check your connection and try again.', 'smart-site-ai-chatbot' ),
				'invalidEmail'     => __( 'Please enter a valid email address.', 'smart-site-ai-chatbot' ),
				'submitting'       => __( 'Submitting...', 'smart-site-ai-chatbot' ),
				'tryAgain'         => __( 'Try again', 'smart-site-ai-chatbot' ),
				'submitted'        => __( 'Submitted.', 'smart-site-ai-chatbot' ),
				'relatedLabel'     => __( 'Related items', 'smart-site-ai-chatbot' ),
				'viewDetails'      => __( 'View details', 'smart-site-ai-chatbot' ),
				'bookOrInquire'    => __( 'Book or inquire', 'smart-site-ai-chatbot' ),
				'whatsappLabel'    => __( 'Chat on WhatsApp', 'smart-site-ai-chatbot' ),
				'emailLabel'       => __( 'Email', 'smart-site-ai-chatbot' ),
				'subscribeTitle'   => __( 'Newsletter signup', 'smart-site-ai-chatbot' ),
				'subscribeBtn'     => __( 'Subscribe', 'smart-site-ai-chatbot' ),
				'bookingTitle'     => __( 'Book a call', 'smart-site-ai-chatbot' ),
				'bookingBtn'       => __( 'Confirm booking', 'smart-site-ai-chatbot' ),
				'inquiryTitle'     => __( 'Project inquiry', 'smart-site-ai-chatbot' ),
				'inquiryBtn'       => __( 'Submit inquiry', 'smart-site-ai-chatbot' ),
				'fieldName'        => __( 'Your full name', 'smart-site-ai-chatbot' ),
				'fieldEmail'       => __( 'Your email address', 'smart-site-ai-chatbot' ),
				'fieldPhone'       => __( 'Phone (optional)', 'smart-site-ai-chatbot' ),
				'fieldDateTime'    => __( 'Preferred date and time', 'smart-site-ai-chatbot' ),
				'fieldMessage'     => __( 'Tell us what you need', 'smart-site-ai-chatbot' ),
			),
		);
	}

	/**
	 * Enqueue the widget assets.
	 *
	 * @return void
	 */
	/**
	 * Asset version string.
	 *
	 * Uses the plugin version in production, and the file modification time
	 * while debugging so local changes are picked up without a hard refresh.
	 *
	 * @param string $relative_path Path inside the plugin folder.
	 * @return string
	 */
	private static function asset_version( $relative_path ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			$file = SSAC_PLUGIN_DIR . $relative_path;

			if ( file_exists( $file ) ) {
				return SSAC_VERSION . '.' . filemtime( $file );
			}
		}

		return SSAC_VERSION;
	}

	public static function enqueue_assets() {
		if ( ! self::is_enabled() ) {
			return;
		}

		$settings = ssac_get_settings();

		wp_enqueue_style(
			'ssac-chatbot',
			SSAC_PLUGIN_URL . 'assets/css/chatbot.css',
			array(),
			self::asset_version( 'assets/css/chatbot.css' )
		);

		$primary   = ! empty( $settings['primary_color'] ) ? $settings['primary_color'] : '#4F46E5';
		$accent    = ! empty( $settings['accent_color'] ) ? $settings['accent_color'] : '#4338CA';
		$header_bg = ! empty( $settings['header_bg'] ) ? $settings['header_bg'] : '#0F172A';

		wp_add_inline_style(
			'ssac-chatbot',
			sprintf(
				':root{--ssac-primary:%1$s;--ssac-accent:%2$s;--ssac-header-bg:%3$s;}',
				sanitize_hex_color( $primary ) ? sanitize_hex_color( $primary ) : '#4F46E5',
				sanitize_hex_color( $accent ) ? sanitize_hex_color( $accent ) : '#4338CA',
				sanitize_hex_color( $header_bg ) ? sanitize_hex_color( $header_bg ) : '#0F172A'
			)
		);

		/*
		 * Deferred so the widget never blocks rendering. WordPress 6.3 and above
		 * reads the array; older versions treat it as a truthy $in_footer, which
		 * is the behaviour we want there anyway.
		 */
		wp_enqueue_script(
			'ssac-chatbot',
			SSAC_PLUGIN_URL . 'assets/js/chatbot.js',
			array(),
			self::asset_version( 'assets/js/chatbot.js' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		wp_localize_script( 'ssac-chatbot', 'SSAC_CONFIG', self::get_frontend_config( $settings ) );

		self::$enqueued = true;
	}

	/**
	 * Register the editor block.
	 *
	 * @return void
	 */
	public static function register_block() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		if ( WP_Block_Type_Registry::get_instance()->is_registered( 'smart-site-ai-chatbot/inline-chat' ) ) {
			return;
		}

		register_block_type(
			'smart-site-ai-chatbot/inline-chat',
			array(
				'api_version'     => 2,
				'title'           => __( 'Smart Site AI Chatbot', 'smart-site-ai-chatbot' ),
				'category'        => 'widgets',
				'render_callback' => array( __CLASS__, 'render_shortcode' ),
				'attributes'      => array(
					'title'    => array(
						'type'    => 'string',
						'default' => '',
					),
					'subtitle' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);
	}

	/**
	 * Render the inline launcher card.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function render_shortcode( $atts = array() ) {
		if ( ! self::is_enabled() ) {
			return '';
		}

		$settings = ssac_get_settings();

		$atts = shortcode_atts(
			array(
				'title'    => $settings['bot_name'],
				'subtitle' => $settings['bot_subtitle'],
			),
			is_array( $atts ) ? $atts : array(),
			'smart_site_ai_chatbot'
		);

		ob_start();
		?>
		<div class="ssac-inline-embed-card">
			<div class="ssac-inline-embed-head">
				<div class="ssac-inline-embed-avatar">
					<?php echo self::get_launcher_svg( 'chat' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static inline SVG markup. ?>
				</div>
				<div class="ssac-inline-embed-meta">
					<strong><?php echo esc_html( $atts['title'] ); ?></strong>
					<span><i class="ssac-dot"></i> <?php echo esc_html( $atts['subtitle'] ); ?></span>
				</div>
			</div>
			<p class="ssac-inline-embed-welcome"><?php echo esc_html( $settings['welcome_message'] ); ?></p>
			<div class="ssac-inline-embed-actions">
				<button type="button" class="ssac-inline-trigger-btn" data-ssac-open="">
					<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
					<span><?php esc_html_e( 'Open the assistant', 'smart-site-ai-chatbot' ); ?></span>
				</button>
				<button type="button" class="ssac-inline-chip-btn" data-ssac-open="<?php echo esc_attr__( 'What services do you offer?', 'smart-site-ai-chatbot' ); ?>">
					<?php esc_html_e( 'Explore services', 'smart-site-ai-chatbot' ); ?>
				</button>
				<button type="button" class="ssac-inline-chip-btn" data-ssac-open="<?php echo esc_attr__( 'Book a consultation call', 'smart-site-ai-chatbot' ); ?>">
					<?php esc_html_e( 'Book a call', 'smart-site-ai-chatbot' ); ?>
				</button>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * The quick actions generated for this site by the indexer.
	 *
	 * @return array
	 */
	public static function get_quick_actions() {
		$index   = SSAC_Knowledge_Indexer::get_memory_index();
		$actions = isset( $index['quick_actions'] ) && is_array( $index['quick_actions'] ) ? $index['quick_actions'] : array();

		if ( empty( $actions ) ) {
			$actions = array(
				array(
					'label'  => __( 'Book a call', 'smart-site-ai-chatbot' ),
					'prompt' => __( 'Book a call', 'smart-site-ai-chatbot' ),
					'icon'   => 'calendar',
				),
				array(
					'label'  => __( 'Contact us', 'smart-site-ai-chatbot' ),
					'prompt' => __( 'Project inquiry', 'smart-site-ai-chatbot' ),
					'icon'   => 'mail',
				),
			);
		}

		return $actions;
	}

	/**
	 * Inline stroke icon for a quick action.
	 *
	 * @param string $name Icon name.
	 * @return string
	 */
	public static function get_action_icon( $name ) {
		$attrs = 'viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"';

		switch ( $name ) {
			case 'box':
				$path = '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>';
				break;

			case 'tag':
				$path = '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r="1"/>';
				break;

			case 'package':
				$path = '<path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/>';
				break;

			case 'chart':
				$path = '<path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/>';
				break;

			case 'calendar':
				$path = '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>';
				break;

			case 'file':
				$path = '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v5h5"/><path d="M9 13h6M9 17h4"/>';
				break;

			case 'mail':
				$path = '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>';
				break;

			case 'briefcase':
			default:
				$path = '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>';
				break;
		}

		return '<svg ' . $attrs . '>' . $path . '</svg>';
	}

	/**
	 * Inline stroke icons for the launcher.
	 *
	 * @param string $icon_type  Icon name.
	 * @param string $custom_url Custom image URL.
	 * @return string
	 */
	public static function get_launcher_svg( $icon_type, $custom_url = '' ) {
		if ( 'custom' === $icon_type && ! empty( $custom_url ) ) {
			return '<img src="' . esc_url( $custom_url ) . '" alt="" class="ssac-custom-launcher-img" />';
		}

		switch ( $icon_type ) {
			case 'robot':
				return '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="8" width="18" height="12" rx="4"/><path d="M12 4v4"/><circle cx="12" cy="3" r="1"/><circle cx="9" cy="14" r="1.2" fill="currentColor"/><circle cx="15" cy="14" r="1.2" fill="currentColor"/><path d="M9 17.5h6"/></svg>';

			case 'sparkles':
				return '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/></svg>';

			case 'bolt':
				return '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>';

			case 'chat':
			default:
				return '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/><path d="M8 12h.01"/><path d="M12 12h.01"/><path d="M16 12h.01"/></svg>';
		}
	}

	/**
	 * Print the floating widget markup.
	 *
	 * @return void
	 */
	public static function render_widget() {
		if ( self::$rendered || ! self::is_enabled() ) {
			return;
		}

		/*
		 * Nothing to bind to if the assets never queued. The handle cannot be
		 * checked with wp_script_is( 'enqueued' ) here: footer scripts leave the
		 * queue while the head is printed, long before this runs.
		 */
		if ( ! self::$enqueued ) {
			return;
		}

		self::$rendered = true;

		$settings     = ssac_get_settings();
		$pos_class    = ( 'left' === $settings['position'] ) ? 'ssac-pos-left' : 'ssac-pos-right';
		$theme_class  = ( 'dark' === $settings['theme_mode'] ) ? 'ssac-theme-dark' : 'ssac-theme-light';
		$launcher_svg = self::get_launcher_svg( $settings['launcher_icon'], $settings['launcher_custom_img'] );
		$page_context = self::get_page_aware_context( $settings );
		$prompts      = $page_context['prompts'];
		?>
		<div id="ssac-root" class="ssac-root <?php echo esc_attr( $pos_class . ' ' . $theme_class ); ?>">

			<?php if ( '1' === $settings['show_tooltip'] && ! empty( $settings['tooltip_text'] ) ) : ?>
				<div id="ssac-tooltip" class="ssac-tooltip">
					<span class="ssac-tooltip-status-dot"></span>
					<span class="ssac-tooltip-text"><?php echo esc_html( $settings['tooltip_text'] ); ?></span>
					<button type="button" id="ssac-tooltip-close" class="ssac-tooltip-close" aria-label="<?php esc_attr_e( 'Dismiss', 'smart-site-ai-chatbot' ); ?>">&times;</button>
				</div>
			<?php endif; ?>

			<button type="button" id="ssac-launcher" class="ssac-launcher" aria-label="<?php esc_attr_e( 'Open the assistant', 'smart-site-ai-chatbot' ); ?>" aria-expanded="false" aria-controls="ssac-window">
				<span class="ssac-launcher-ring"></span>
				<span class="ssac-launcher-icon-open"><?php echo $launcher_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static inline SVG markup or an escaped image tag. ?></span>
				<span class="ssac-launcher-icon-close">
					<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
				</span>
				<span class="ssac-online-dot"></span>
			</button>

			<div id="ssac-window" class="ssac-window" role="dialog" aria-modal="false" aria-label="<?php echo esc_attr( $settings['bot_name'] ); ?>" aria-hidden="true">

				<div class="ssac-header">
					<div class="ssac-header-brand">
						<div class="ssac-avatar">
							<?php if ( ! empty( $settings['bot_avatar'] ) ) : ?>
								<img src="<?php echo esc_url( $settings['bot_avatar'] ); ?>" alt="" />
							<?php else : ?>
								<?php echo self::get_launcher_svg( 'chat' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static inline SVG markup. ?>
							<?php endif; ?>
							<span class="ssac-avatar-status"></span>
						</div>
						<div class="ssac-header-meta">
							<div class="ssac-header-title-row">
								<h3 class="ssac-title"><?php echo esc_html( $settings['bot_name'] ); ?></h3>
								<span class="ssac-context-pill"><?php echo esc_html( $page_context['badge'] ); ?></span>
							</div>
							<p class="ssac-subtitle"><span class="ssac-pulse"></span> <?php echo esc_html( $settings['bot_subtitle'] ); ?></p>
						</div>
					</div>
					<div class="ssac-header-actions">
						<button type="button" id="ssac-theme-toggle" class="ssac-icon-btn" aria-label="<?php esc_attr_e( 'Switch light or dark mode', 'smart-site-ai-chatbot' ); ?>">
							<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>
						</button>
						<button type="button" id="ssac-reset-chat" class="ssac-icon-btn" aria-label="<?php esc_attr_e( 'Reset the conversation', 'smart-site-ai-chatbot' ); ?>">
							<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
						</button>
						<button type="button" id="ssac-close-window" class="ssac-icon-btn" aria-label="<?php esc_attr_e( 'Minimise', 'smart-site-ai-chatbot' ); ?>">
							<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
						</button>
					</div>
				</div>

				<div class="ssac-action-dock">
					<?php foreach ( self::get_quick_actions() as $action ) : ?>
						<button type="button" class="ssac-dock-btn" data-prompt="<?php echo esc_attr( $action['prompt'] ); ?>">
							<?php echo self::get_action_icon( isset( $action['icon'] ) ? $action['icon'] : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static inline SVG markup. ?>
							<span><?php echo esc_html( $action['label'] ); ?></span>
						</button>
					<?php endforeach; ?>
				</div>

				<?php if ( isset( $settings['enable_gdpr_consent'] ) && '1' === $settings['enable_gdpr_consent'] ) : ?>
					<div id="ssac-gdpr-banner" class="ssac-gdpr-banner" style="display:none;">
						<div class="ssac-gdpr-icon">
							<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
						</div>
						<div class="ssac-gdpr-body">
							<p><?php echo esc_html( $settings['gdpr_consent_text'] ); ?></p>
							<button type="button" id="ssac-gdpr-accept" class="ssac-gdpr-accept-btn"><?php esc_html_e( 'Accept and continue', 'smart-site-ai-chatbot' ); ?></button>
						</div>
					</div>
				<?php endif; ?>

				<div id="ssac-messages" class="ssac-messages" aria-live="polite"></div>

				<div id="ssac-chips" class="ssac-chips">
					<?php foreach ( array_slice( $prompts, 0, 3 ) as $prompt ) : ?>
						<button type="button" class="ssac-chip" data-prompt="<?php echo esc_attr( $prompt ); ?>"><?php echo esc_html( $prompt ); ?></button>
					<?php endforeach; ?>
				</div>

				<form id="ssac-form" class="ssac-composer" autocomplete="off">
					<label for="ssac-input" class="ssac-sr-only"><?php esc_html_e( 'Your message', 'smart-site-ai-chatbot' ); ?></label>
					<div class="ssac-input-wrap">
						<textarea id="ssac-input" class="ssac-input" rows="1" maxlength="<?php echo esc_attr( SSAC_Chat_Engine::MAX_MESSAGE_LEN ); ?>" placeholder="<?php esc_attr_e( 'Ask a question, check an order, or book a call', 'smart-site-ai-chatbot' ); ?>"></textarea>
						<?php if ( '1' === $settings['enable_voice'] ) : ?>
							<button type="button" id="ssac-voice-btn" class="ssac-voice-btn" aria-label="<?php esc_attr_e( 'Voice input', 'smart-site-ai-chatbot' ); ?>">
								<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="22"/></svg>
							</button>
						<?php endif; ?>
					</div>
					<button type="submit" id="ssac-send-btn" class="ssac-send-btn" aria-label="<?php esc_attr_e( 'Send message', 'smart-site-ai-chatbot' ); ?>">
						<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
					</button>
				</form>

				<?php if ( isset( $settings['show_credit_link'] ) && '1' === $settings['show_credit_link'] && ! empty( $settings['business_name'] ) ) : ?>
					<div class="ssac-footer">
						<span>
							<?php if ( ! empty( $settings['business_website'] ) ) : ?>
								<a href="<?php echo esc_url( $settings['business_website'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $settings['business_name'] ); ?></a>
							<?php else : ?>
								<?php echo esc_html( $settings['business_name'] ); ?>
							<?php endif; ?>
						</span>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
