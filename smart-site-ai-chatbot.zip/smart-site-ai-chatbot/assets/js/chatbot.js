/**
 * Smart Site AI Chatbot - frontend controller.
 *
 * @package Smart_Site_AI_Chatbot
 */
(function () {
	'use strict';

	if (typeof window.SSAC_CONFIG === 'undefined') {
		return;
	}

	var CFG = window.SSAC_CONFIG;
	var T = CFG.i18n || {};
	var STORAGE_KEY = 'ssac_chat_session';
	var TOKEN_KEY = 'ssac_visitor_token';
	var OPEN_STATE_KEY = 'ssac_window_open';
	var GDPR_KEY = 'ssac_gdpr_accepted';

	var root;
	var launcher;
	var chatWindow;
	var closeBtn;
	var resetBtn;
	var themeBtn;
	var tooltip;
	var tooltipClose;
	var messagesEl;
	var chipsEl;
	var formEl;
	var inputEl;
	var voiceBtn;
	var gdprBanner;
	var gdprAcceptBtn;

	var isOpen = false;
	var isSending = false;
	var conversation = [];
	var pendingPrompt = '';

	/* ---------------------------------------------------------------------
	 * Storage helpers. Every call is guarded: storage throws in private
	 * browsing modes and when site data is blocked.
	 * ------------------------------------------------------------------ */

	function storageGet(store, key) {
		try {
			return window[store].getItem(key);
		} catch (e) {
			return null;
		}
	}

	function storageSet(store, key, value) {
		try {
			window[store].setItem(key, value);
		} catch (e) {
			/* Storage unavailable: the widget still works for this page view. */
		}
	}

	function storageRemove(store, key) {
		try {
			window[store].removeItem(key);
		} catch (e) {
			/* Nothing to do. */
		}
	}

	/**
	 * Opaque per-browser token. The server derives the session key from it, so
	 * visitors sharing a public IP address never share a conversation.
	 */
	function getVisitorToken() {
		var token = storageGet('localStorage', TOKEN_KEY);

		if (token && /^[a-f0-9]{32}$/.test(token)) {
			return token;
		}

		token = '';

		if (window.crypto && window.crypto.getRandomValues) {
			var bytes = new Uint8Array(16);
			window.crypto.getRandomValues(bytes);

			for (var i = 0; i < bytes.length; i++) {
				token += ('0' + bytes[i].toString(16)).slice(-2);
			}
		} else {
			while (token.length < 32) {
				token += Math.floor(Math.random() * 16).toString(16);
			}
		}

		storageSet('localStorage', TOKEN_KEY, token);

		return token;
	}

	function getTtlMs() {
		var hours = parseInt(CFG.sessionTtlHours, 10) || 24;
		return hours * 3600 * 1000;
	}

	/* ---------------------------------------------------------------------
	 * Escaping. escapeHtml is for text nodes, escapeAttr for attribute
	 * values: a text-node escape leaves quotes intact, which would let a
	 * quote in a title or URL break out of the attribute.
	 * ------------------------------------------------------------------ */

	function escapeHtml(str) {
		return String(str === null || typeof str === 'undefined' ? '' : str)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;');
	}

	function escapeAttr(str) {
		return escapeHtml(str).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
	}

	/**
	 * Only allow links the browser can safely follow.
	 */
	function safeUrl(url) {
		var raw = String(url === null || typeof url === 'undefined' ? '' : url).trim();

		if (/^(https?:|mailto:|tel:|\/|#)/i.test(raw)) {
			return raw;
		}

		return '';
	}

	function formatMarkdown(text) {
		var safe = escapeHtml(text);

		safe = safe.replace(/`([^`]+)`/g, '<code>$1</code>');
		safe = safe.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
		safe = safe.replace(/\*([^*]+)\*/g, '<em>$1</em>');
		safe = safe.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)"']+)\)/g, function (match, label, href) {
			return '<a href="' + escapeAttr(href) + '" target="_blank" rel="noopener noreferrer">' + label + '</a>';
		});
		safe = safe.replace(/\n/g, '<br>');

		return safe;
	}

	/* ---------------------------------------------------------------------
	 * Requests.
	 * ------------------------------------------------------------------ */

	function buildFormData(action) {
		var fd = new FormData();

		fd.append('action', action);
		fd.append('ssac_nonce', CFG.nonce || '');
		fd.append('visitor_token', getVisitorToken());

		return fd;
	}

	function postToServer(formData) {
		return fetch(CFG.ajaxUrl, {
			method: 'POST',
			body: formData,
			credentials: 'same-origin'
		}).then(function (r) {
			return r.json();
		});
	}

	/* ---------------------------------------------------------------------
	 * Local conversation cache.
	 * ------------------------------------------------------------------ */

	function saveLocalSession() {
		storageSet(
			'localStorage',
			STORAGE_KEY,
			JSON.stringify({
				conversation: conversation.slice(-30),
				savedAt: Date.now()
			})
		);
	}

	function loadLocalSession() {
		var raw = storageGet('localStorage', STORAGE_KEY);

		if (!raw) {
			return false;
		}

		try {
			var parsed = JSON.parse(raw);

			if (!parsed || !Array.isArray(parsed.conversation) || !parsed.conversation.length) {
				return false;
			}

			if (parsed.savedAt && Date.now() - parsed.savedAt > getTtlMs()) {
				storageRemove('localStorage', STORAGE_KEY);
				return false;
			}

			conversation = parsed.conversation;

			return true;
		} catch (e) {
			return false;
		}
	}

	function renderStoredConversation() {
		messagesEl.innerHTML = '';

		conversation.forEach(function (msg) {
			appendMessageDOM(
				msg.role,
				msg.text,
				msg.cards || [],
				msg.images || [],
				msg.action_form || '',
				msg.handoff || null,
				false
			);
		});

		messagesEl.scrollTop = messagesEl.scrollHeight;
	}

	/**
	 * Restore the conversation stored against this browser's token, so the chat
	 * survives navigation and reloads.
	 */
	function syncWithServerSession() {
		postToServer(buildFormData('ssac_load_session'))
			.then(function (res) {
				if (!res || !res.success || !res.data || !Array.isArray(res.data.messages)) {
					return;
				}

				var serverMsgs = res.data.messages;

				if (!serverMsgs.length || serverMsgs.length < conversation.length) {
					return;
				}

				conversation = [
					{
						role: 'bot',
						text: CFG.defaultGreeting || CFG.welcomeMessage || T.greetingFallback,
						cards: [],
						images: [],
						action_form: '',
						handoff: null
					}
				].concat(serverMsgs);

				saveLocalSession();
				renderStoredConversation();
			})
			.catch(function () {
				/* Offline or blocked: the local cache is already rendered. */
			});
	}

	/* ---------------------------------------------------------------------
	 * Consent gate.
	 * ------------------------------------------------------------------ */

	function hasConsent() {
		if (!CFG.enableGdpr) {
			return true;
		}

		return storageGet('localStorage', GDPR_KEY) === '1';
	}

	function refreshConsentGate() {
		if (!CFG.enableGdpr || !gdprBanner) {
			return;
		}

		var accepted = hasConsent();

		gdprBanner.style.display = accepted ? 'none' : 'flex';

		if (formEl) {
			formEl.classList.toggle('ssac-composer-locked', !accepted);
		}

		if (inputEl) {
			inputEl.disabled = !accepted;
		}
	}

	/* ---------------------------------------------------------------------
	 * Window state.
	 * ------------------------------------------------------------------ */

	function toggleWindow(forceState) {
		isOpen = typeof forceState === 'boolean' ? forceState : !isOpen;

		root.classList.toggle('ssac-open', isOpen);
		launcher.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
		chatWindow.setAttribute('aria-hidden', isOpen ? 'false' : 'true');

		if (tooltip && isOpen) {
			tooltip.style.display = 'none';
		}

		storageSet('sessionStorage', OPEN_STATE_KEY, isOpen ? '1' : '0');

		if (isOpen) {
			refreshConsentGate();

			window.setTimeout(function () {
				messagesEl.scrollTop = messagesEl.scrollHeight;

				if (!inputEl.disabled) {
					inputEl.focus();
				}
			}, 120);
		}
	}

	/* ---------------------------------------------------------------------
	 * Rendering.
	 * ------------------------------------------------------------------ */

	function createCardsHTML(cards) {
		if (!Array.isArray(cards) || !cards.length) {
			return '';
		}

		var hasRelated = cards.some(function (c) {
			return c.is_related;
		});

		var html = '<div class="ssac-cards-wrap">';

		if (hasRelated) {
			html += '<div class="ssac-related-label">' + escapeHtml(T.relatedLabel) + '</div>';
		}

		cards.slice(0, 3).forEach(function (c) {
			var url = safeUrl(c.url);
			var priceVal = c.price_label || c.price || '';
			var priceHtml =
				priceVal && priceVal !== c.category
					? '<span class="ssac-card-price">' + escapeHtml(priceVal) + '</span>'
					: '';

			var imgUrl = safeUrl(c.image);
			var thumbHtml = imgUrl
				? '<div class="ssac-card-thumb"><img src="' +
					escapeAttr(imgUrl) +
					'" alt="" loading="lazy"></div>'
				: '<div class="ssac-card-thumb ssac-card-thumb-fallback"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg></div>';

			var summaryText = escapeHtml(c.summary || '');

			html +=
				'<div class="ssac-item-card">' +
					'<div class="ssac-item-card-top">' +
						thumbHtml +
						'<div class="ssac-item-card-info">' +
							'<div class="ssac-item-card-badges">' +
								'<span class="ssac-card-badge">' + escapeHtml(c.category || c.type || '') + '</span>' +
								priceHtml +
							'</div>' +
							'<a href="' + escapeAttr(url) + '" class="ssac-card-title">' + escapeHtml(c.title) + '</a>' +
							'<p class="ssac-card-desc">' + summaryText + '</p>' +
						'</div>' +
					'</div>' +
					'<div class="ssac-item-card-actions">' +
						'<a href="' + escapeAttr(url) + '" class="ssac-card-btn-view">' +
							'<span>' + escapeHtml(T.viewDetails) + '</span>' +
						'</a>' +
						'<button type="button" class="ssac-card-btn-book" data-book-service="' +
							escapeAttr(c.title) + '">' + escapeHtml(T.bookOrInquire) + '</button>' +
					'</div>' +
				'</div>';
		});

		html += '</div>';

		return html;
	}

	function createImagesGridHTML(images) {
		if (!Array.isArray(images) || !images.length) {
			return '';
		}

		var html = '<div class="ssac-img-grid">';

		images.slice(0, 3).forEach(function (img) {
			var imgUrl = safeUrl(img.url);

			if (!imgUrl) {
				return;
			}

			var linkUrl = safeUrl(img.page_url) || imgUrl;
			var label = img.alt || img.page_title || '';

			html +=
				'<a href="' + escapeAttr(linkUrl) + '" class="ssac-img-card">' +
					'<img src="' + escapeAttr(imgUrl) + '" alt="' + escapeAttr(label) + '" loading="lazy">' +
					'<span>' + escapeHtml(label) + '</span>' +
				'</a>';
		});

		html += '</div>';

		return html;
	}

	function createHandoffCardHTML(handoff) {
		if (!handoff || typeof handoff !== 'object') {
			return '';
		}

		var html = '<div class="ssac-handoff-card">';
		var waUrl = safeUrl(handoff.whatsapp_url);

		if (waUrl) {
			html +=
				'<a href="' + escapeAttr(waUrl) + '" target="_blank" rel="noopener noreferrer" class="ssac-handoff-btn ssac-handoff-wa">' +
					'<span>' + escapeHtml(T.whatsappLabel) + '</span>' +
				'</a>';
		}

		if (handoff.email) {
			html +=
				'<a href="mailto:' + escapeAttr(handoff.email) + '" class="ssac-handoff-btn ssac-handoff-mail">' +
					'<span>' + escapeHtml(T.emailLabel) + ': ' + escapeHtml(handoff.email) + '</span>' +
				'</a>';
		}

		html += '</div>';

		return html;
	}

	function createQuickActionFormHTML(formType) {
		if (!formType) {
			return '';
		}

		if (formType === 'subscribe') {
			return (
				'<div class="ssac-inline-form" data-form-type="subscribe">' +
					'<div class="ssac-inline-form-title">' + escapeHtml(T.subscribeTitle) + '</div>' +
					'<input type="email" class="ssac-if-email" placeholder="' + escapeAttr(T.fieldEmail) + '">' +
					'<button type="button" class="ssac-if-submit">' + escapeHtml(T.subscribeBtn) + '</button>' +
				'</div>'
			);
		}

		if (formType === 'booking') {
			return (
				'<div class="ssac-inline-form" data-form-type="booking">' +
					'<div class="ssac-inline-form-title">' + escapeHtml(T.bookingTitle) + '</div>' +
					'<input type="text" class="ssac-if-name" placeholder="' + escapeAttr(T.fieldName) + '">' +
					'<input type="email" class="ssac-if-email" placeholder="' + escapeAttr(T.fieldEmail) + '">' +
					'<input type="text" class="ssac-if-phone" placeholder="' + escapeAttr(T.fieldPhone) + '">' +
					'<input type="text" class="ssac-if-datetime" placeholder="' + escapeAttr(T.fieldDateTime) + '">' +
					'<button type="button" class="ssac-if-submit">' + escapeHtml(T.bookingBtn) + '</button>' +
				'</div>'
			);
		}

		if (formType === 'inquiry') {
			return (
				'<div class="ssac-inline-form" data-form-type="inquiry">' +
					'<div class="ssac-inline-form-title">' + escapeHtml(T.inquiryTitle) + '</div>' +
					'<input type="text" class="ssac-if-name" placeholder="' + escapeAttr(T.fieldName) + '">' +
					'<input type="email" class="ssac-if-email" placeholder="' + escapeAttr(T.fieldEmail) + '">' +
					'<textarea class="ssac-if-message" rows="2" placeholder="' + escapeAttr(T.fieldMessage) + '"></textarea>' +
					'<button type="button" class="ssac-if-submit">' + escapeHtml(T.inquiryBtn) + '</button>' +
				'</div>'
			);
		}

		return '';
	}

	function appendMessageDOM(role, text, cards, images, actionForm, handoff, animate) {
		var row = document.createElement('div');

		row.className = 'ssac-msg-row ssac-msg-' + (role === 'user' ? 'user' : 'bot') + (animate ? ' ssac-msg-anim' : '');

		var html = '<div class="ssac-msg-bubble">' + formatMarkdown(text) + '</div>';

		if (role !== 'user') {
			html += createCardsHTML(cards);
			html += createImagesGridHTML(images);
			html += createHandoffCardHTML(handoff);
			html += createQuickActionFormHTML(actionForm);
		}

		row.innerHTML = html;
		messagesEl.appendChild(row);
		messagesEl.scrollTop = messagesEl.scrollHeight;
	}

	function addMessage(role, text, cards, images, actionForm, handoff) {
		appendMessageDOM(role, text, cards || [], images || [], actionForm || '', handoff || null, true);

		conversation.push({
			role: role,
			text: text,
			cards: cards || [],
			images: images || [],
			action_form: actionForm || '',
			handoff: handoff || null
		});

		saveLocalSession();
	}

	function showTypingIndicator() {
		var row = document.createElement('div');

		row.id = 'ssac-typing';
		row.className = 'ssac-msg-row ssac-msg-bot';
		row.innerHTML = '<div class="ssac-msg-bubble ssac-typing-bubble"><span></span><span></span><span></span></div>';

		messagesEl.appendChild(row);
		messagesEl.scrollTop = messagesEl.scrollHeight;
	}

	function hideTypingIndicator() {
		var el = document.getElementById('ssac-typing');

		if (el && el.parentNode) {
			el.parentNode.removeChild(el);
		}
	}

	function renderSuggestions(suggestions) {
		if (!chipsEl || !Array.isArray(suggestions) || !suggestions.length) {
			return;
		}

		chipsEl.innerHTML = '';

		suggestions.slice(0, 3).forEach(function (s) {
			var btn = document.createElement('button');

			btn.type = 'button';
			btn.className = 'ssac-chip';
			btn.setAttribute('data-prompt', s);
			btn.textContent = s;

			chipsEl.appendChild(btn);
		});
	}

	function playPopSound() {
		if (!CFG.enableSound) {
			return;
		}

		try {
			var Ctx = window.AudioContext || window.webkitAudioContext;

			if (!Ctx) {
				return;
			}

			var ctx = new Ctx();
			var osc = ctx.createOscillator();
			var gain = ctx.createGain();

			osc.type = 'sine';
			osc.frequency.setValueAtTime(540, ctx.currentTime);
			osc.frequency.exponentialRampToValueAtTime(780, ctx.currentTime + 0.08);
			gain.gain.setValueAtTime(0.035, ctx.currentTime);
			gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.11);
			osc.connect(gain);
			gain.connect(ctx.destination);
			osc.start();
			osc.stop(ctx.currentTime + 0.11);
		} catch (e) {
			/* Audio is a nice-to-have. */
		}
	}

	/* ---------------------------------------------------------------------
	 * Sending.
	 * ------------------------------------------------------------------ */

	function sendMessage(messageText, hiddenCommand) {
		var cleanText = String(messageText || '').trim();

		if (!cleanText || isSending || !hasConsent()) {
			return;
		}

		if (CFG.maxMessageLen && cleanText.length > CFG.maxMessageLen) {
			cleanText = cleanText.substring(0, CFG.maxMessageLen);
		}

		isSending = true;
		addMessage('user', cleanText);
		inputEl.value = '';
		inputEl.style.height = 'auto';
		showTypingIndicator();

		var fd = buildFormData('ssac_send_message');

		fd.append('message', hiddenCommand || cleanText);
		fd.append('current_url', window.location.href);
		fd.append('page_title', document.title);

		postToServer(fd)
			.then(function (res) {
				hideTypingIndicator();
				isSending = false;

				if (res && res.success && res.data) {
					var d = res.data;

					addMessage('bot', d.reply, d.cards || [], d.images || [], d.action_form || '', d.handoff || null);
					playPopSound();

					if (d.suggestions && d.suggestions.length) {
						renderSuggestions(d.suggestions);
					}

					return;
				}

				var errMsg = res && res.data && res.data.message ? res.data.message : T.genericError;
				addMessage('bot', errMsg);
			})
			.catch(function () {
				hideTypingIndicator();
				isSending = false;
				addMessage('bot', T.networkError);
			});
	}

	function submitInlineForm(inlineSubmit) {
		var box = inlineSubmit.closest('.ssac-inline-form');

		if (!box) {
			return;
		}

		function fieldValue(selector) {
			var el = box.querySelector(selector);
			return el ? el.value.trim() : '';
		}

		var type = box.getAttribute('data-form-type') || 'inquiry';
		var emailVal = fieldValue('.ssac-if-email');

		if (!emailVal || emailVal.indexOf('@') === -1) {
			var warn = box.querySelector('.ssac-if-error');

			if (!warn) {
				warn = document.createElement('p');
				warn.className = 'ssac-if-error';
				box.appendChild(warn);
			}

			warn.textContent = T.invalidEmail;

			return;
		}

		inlineSubmit.disabled = true;
		inlineSubmit.textContent = T.submitting;

		var fd = buildFormData('ssac_direct_action_submit');

		fd.append('action_type', type);
		fd.append('name', fieldValue('.ssac-if-name'));
		fd.append('email', emailVal);
		fd.append('phone', fieldValue('.ssac-if-phone'));
		fd.append('date_time', fieldValue('.ssac-if-datetime'));
		fd.append('message', fieldValue('.ssac-if-message'));

		postToServer(fd)
			.then(function (res) {
				if (res && res.success && res.data) {
					box.innerHTML = '<div class="ssac-inline-success">' + escapeHtml(T.submitted) + '</div>';
					addMessage('bot', res.data.reply);
					playPopSound();
					return;
				}

				inlineSubmit.disabled = false;
				inlineSubmit.textContent = T.tryAgain;
			})
			.catch(function () {
				inlineSubmit.disabled = false;
				inlineSubmit.textContent = T.tryAgain;
			});
	}

	/* ---------------------------------------------------------------------
	 * Wiring.
	 * ------------------------------------------------------------------ */

	function bindEvents() {
		launcher.addEventListener('click', function () {
			toggleWindow();
		});

		if (closeBtn) {
			closeBtn.addEventListener('click', function () {
				toggleWindow(false);
			});
		}

		if (tooltip) {
			tooltip.addEventListener('click', function (e) {
				if (e.target === tooltipClose) {
					return;
				}

				toggleWindow(true);
			});
		}

		if (tooltipClose) {
			tooltipClose.addEventListener('click', function (e) {
				e.stopPropagation();
				tooltip.style.display = 'none';
			});
		}

		if (themeBtn) {
			themeBtn.addEventListener('click', function () {
				var isDark = root.classList.contains('ssac-theme-dark');

				root.classList.toggle('ssac-theme-dark', !isDark);
				root.classList.toggle('ssac-theme-light', isDark);
			});
		}

		if (resetBtn) {
			resetBtn.addEventListener('click', function () {
				conversation = [];
				storageRemove('localStorage', STORAGE_KEY);

				postToServer(buildFormData('ssac_clear_session')).catch(function () {});

				messagesEl.innerHTML = '';
				addMessage('bot', CFG.welcomeMessage || T.greetingFallback);

				if (CFG.demoPrompts && CFG.demoPrompts.length) {
					renderSuggestions(CFG.demoPrompts);
				}
			});
		}

		if (gdprAcceptBtn) {
			gdprAcceptBtn.addEventListener('click', function () {
				storageSet('localStorage', GDPR_KEY, '1');
				refreshConsentGate();
				inputEl.focus();

				if (pendingPrompt) {
					var queued = pendingPrompt;
					pendingPrompt = '';
					sendMessage(queued);
				}
			});
		}

		formEl.addEventListener('submit', function (e) {
			e.preventDefault();
			sendMessage(inputEl.value);
		});

		inputEl.addEventListener('keydown', function (e) {
			if (e.key === 'Enter' && !e.shiftKey) {
				e.preventDefault();
				sendMessage(inputEl.value);
			}
		});

		inputEl.addEventListener('input', function () {
			this.style.height = 'auto';
			this.style.height = Math.min(this.scrollHeight, 96) + 'px';
		});

		root.addEventListener('click', function (e) {
			var chip = e.target.closest ? e.target.closest('[data-prompt]') : null;

			if (chip) {
				e.preventDefault();

				var prompt = chip.getAttribute('data-prompt');

				if (prompt) {
					sendMessage(prompt);
				}

				return;
			}

			var bookBtn = e.target.closest ? e.target.closest('[data-book-service]') : null;

			if (bookBtn) {
				e.preventDefault();

				var svcName = bookBtn.getAttribute('data-book-service');
				sendMessage(T.bookOrInquire + ': ' + svcName, '#ssac-book:' + encodeURIComponent(svcName));

				return;
			}

			var inlineSubmit = e.target.closest ? e.target.closest('.ssac-if-submit') : null;

			if (inlineSubmit) {
				e.preventDefault();
				submitInlineForm(inlineSubmit);
			}
		});

		// Shortcode and block buttons placed anywhere in the page.
		document.addEventListener('click', function (e) {
			var opener = e.target.closest ? e.target.closest('[data-ssac-open]') : null;

			if (!opener) {
				return;
			}

			e.preventDefault();
			openWithPrompt(opener.getAttribute('data-ssac-open') || '');
		});

		if (voiceBtn) {
			bindVoiceInput();
		}
	}

	function bindVoiceInput() {
		var SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;

		if (!CFG.enableVoice || !SpeechRec) {
			voiceBtn.style.display = 'none';
			return;
		}

		var rec = new SpeechRec();

		rec.continuous = false;
		rec.interimResults = false;
		rec.lang = document.documentElement.lang || 'en-US';

		voiceBtn.addEventListener('click', function () {
			try {
				voiceBtn.classList.add('ssac-recording');
				rec.start();
			} catch (e) {
				voiceBtn.classList.remove('ssac-recording');
			}
		});

		rec.onresult = function (event) {
			voiceBtn.classList.remove('ssac-recording');

			if (event.results && event.results[0] && event.results[0][0]) {
				inputEl.value = event.results[0][0].transcript;
				inputEl.focus();
			}
		};

		rec.onerror = function () {
			voiceBtn.classList.remove('ssac-recording');
		};

		rec.onend = function () {
			voiceBtn.classList.remove('ssac-recording');
		};
	}

	function openWithPrompt(promptText) {
		toggleWindow(true);

		if (!promptText) {
			return;
		}

		if (!hasConsent()) {
			pendingPrompt = promptText;
			return;
		}

		sendMessage(promptText);
	}

	function start() {
		root = document.getElementById('ssac-root');
		launcher = document.getElementById('ssac-launcher');
		chatWindow = document.getElementById('ssac-window');
		closeBtn = document.getElementById('ssac-close-window');
		resetBtn = document.getElementById('ssac-reset-chat');
		themeBtn = document.getElementById('ssac-theme-toggle');
		tooltip = document.getElementById('ssac-tooltip');
		tooltipClose = document.getElementById('ssac-tooltip-close');
		messagesEl = document.getElementById('ssac-messages');
		chipsEl = document.getElementById('ssac-chips');
		formEl = document.getElementById('ssac-form');
		inputEl = document.getElementById('ssac-input');
		voiceBtn = document.getElementById('ssac-voice-btn');
		gdprBanner = document.getElementById('ssac-gdpr-banner');
		gdprAcceptBtn = document.getElementById('ssac-gdpr-accept');

		if (!root || !launcher || !chatWindow || !messagesEl || !formEl || !inputEl) {
			return false;
		}

		bindEvents();
		refreshConsentGate();

		if (loadLocalSession()) {
			renderStoredConversation();
		} else {
			addMessage('bot', CFG.welcomeMessage || T.greetingFallback);
		}

		syncWithServerSession();

		if (storageGet('sessionStorage', OPEN_STATE_KEY) === '1') {
			toggleWindow(true);
		}

		// Kept for themes and page builders that call it directly.
		window.SSAC_OPEN_WITH_PROMPT = openWithPrompt;

		handleHashLink();
		window.addEventListener('hashchange', handleHashLink);

		return true;
	}

	/**
	 * Deep links: #ssac-open opens the assistant, and
	 * #ssac-ask=<question> opens it and asks that question. Useful for a
	 * "Chat with us" menu item or button anywhere on the site.
	 */
	function handleHashLink() {
		var hash = window.location.hash || '';

		if (hash === '#ssac-open') {
			openWithPrompt('');
			return;
		}

		if (hash.indexOf('#ssac-ask=') === 0) {
			var question = '';

			try {
				question = decodeURIComponent(hash.slice('#ssac-ask='.length));
			} catch (e) {
				question = '';
			}

			openWithPrompt(question);
		}
	}

	/*
	 * The markup prints in the footer, so the script may run before it exists.
	 * Try immediately, then on DOMContentLoaded, then once the page has loaded.
	 */
	if (!start()) {
		if (document.readyState === 'loading') {
			document.addEventListener('DOMContentLoaded', function () {
				if (!start()) {
					window.addEventListener('load', start);
				}
			});
		} else {
			window.addEventListener('load', start);
		}
	}
})();
