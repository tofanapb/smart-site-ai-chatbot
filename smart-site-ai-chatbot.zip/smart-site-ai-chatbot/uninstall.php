<?php
/**
 * Uninstall routine.
 *
 * Removes every option, scheduled event, transient and stored lead the plugin
 * created, so deleting the plugin leaves nothing behind.
 *
 * @package Smart_Site_AI_Chatbot
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$ssac_options = array(
	'ssac_chatbot_settings',
	'ssac_site_knowledge_index',
	'ssac_site_knowledge_stats',
	'ssac_total_chats_count',
	'ssac_chat_sessions_index',
	// Keys used by pre-release builds.
	'ssac_site_knowledge_index_v2',
	'ssac_site_knowledge_stats_v2',
	'ssac_site_memory_index',
);

foreach ( $ssac_options as $ssac_option ) {
	delete_option( $ssac_option );
}

wp_clear_scheduled_hook( 'ssac_sync_site_memory_event' );

/*
 * Removed with one query because the transient names are per visitor and cannot
 * be enumerated through the options API. There is nothing to cache: this runs
 * once, at uninstall, and deletes rows.
 */
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_ssac_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_ssac_' ) . '%'
	)
);

// Remove stored leads, bookings and subscribers.
$ssac_leads = get_posts(
	array(
		'post_type'      => 'ssac_lead',
		'posts_per_page' => -1,
		'post_status'    => 'any',
		'fields'         => 'ids',
	)
);

if ( ! empty( $ssac_leads ) ) {
	foreach ( $ssac_leads as $ssac_lead_id ) {
		wp_delete_post( (int) $ssac_lead_id, true );
	}
}
